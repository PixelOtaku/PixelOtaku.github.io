import pygame, time
from .Registry import Singleton
from pygame.math import Vector2 as vec2
from typing import Any
from ..mgl.mgl import MGL, Render_Object
from ..utils.math import clamp

class Window(Singleton):

    """
        REV Window. It creates 2 Surfaces:

        - the first is called the Screen which is the actual window it self and you can call it using Window.screen.
        - the second is called the Display which is where you game is drawn onto, you can call it using Window.display.

        Note[!] - The Display size cannot be changed during runtime but you can change the Screen size

        I made it this way to make scaling the game easier, they both have their own size, the display is blitted onto the screen after it gets scaled to it's size.
        this was made to make scaling up games like pixel art games easier

        There's also an option to enable GPU rendering. When Instantiating the window you can change the GPU_rendering to True or False (it's set to False by default)
    """

    def __init__(self, caption: str, icon_path: str | None=None, display_size: list[int]=[320, 180], screen_size: list[int]=[1280, 720], GPU_rendering: bool=False, flags: Any=0, fps_cap: float=60.0, frag_path: str | None=None, vert_path: str | None=None):
        super().__init__("Window")

        """
            Instantiate the REVe Window.
        """

        # Boilerplate
        self.screen_size: list[int] = screen_size
        self.display_size: list[int] = display_size
        self.start_time: float = time.time()
        self.time: float = time.time()

        self.GPU_rendering: bool = GPU_rendering
        self.flags = flags
        if self.GPU_rendering:
            self.flags = self.flags | pygame.DOUBLEBUF | pygame.OPENGL


        # Creating the actual windows
        self.screen: pygame.Surface = pygame.display.set_mode(screen_size, self.flags)
        self.display: pygame.Surface = pygame.Surface(display_size)
        pygame.display.set_caption(caption)
        if icon_path != None:
            icon_img: pygame.Surface = pygame.image.load(icon_path).convert()
            icon_img = pygame.transform.scale(icon_img, (64,64))
            pygame.display.set_icon(icon_img)
        self.clock: pygame.time.Clock = pygame.time.Clock()


        #The GLSL shit
        self.render_object: Render_Object | None = None
        self.mgl: MGL | None = None
        if self.GPU_rendering:
            self.mgl = MGL()
            self.render_object: Render_Object = self.mgl.get_render_obj(frag_path, vert_path)


        # Some important information
        self.dt: float = 0.01
        self.fps_cap: float = fps_cap
        self.current_fps: float = 0.0
        self.scale: vec2 = vec2([self.display.get_width() / self.screen.get_width(), self.display.get_height() / self.screen.get_height()])


    def cycle(self):

        """
            All the Windows information is updated when you call this function, this includes the display, delta_time, current_fps, and so on ...

            it also updates some built-in stuff like the Input object and the Music object.
        """

        # Update important information in the Window
        self.dt = self.clock.tick(self.fps_cap) / 1000
        self.dt = clamp(self.dt, (1 / self.fps_cap), (2 / self.fps_cap))
        self.current_fps = 1 / self.dt if self.dt != 0 else 0

        # Scale Display and blit onto the screen
        self.scale = vec2([self.display.get_width() / self.screen.get_width(), self.display.get_height() / self.screen.get_height()])
        self.screen.blit(pygame.transform.scale(self.display, self.screen.get_size()), (0,0))

        # Update other singletons
        self.Registry['Game'].Input.update()
        self.Registry['Game'].Music.update()


    def GLDisplay_update(self, uniforms: dict[str, Any]={}) -> None:

        """
            Update the pygame.display (The Window).

            Change the Display into something that can be rendered on the GPU and pass in the necessary uniforms to the GPU if GPU_rendering is enabled.

            if GPU_rendering is not enabled then it just renders the the Window usig the CPU
        """

        if self.GPU_rendering:
            self.render_object.render(self.screen, uniforms)
        pygame.display.flip()
