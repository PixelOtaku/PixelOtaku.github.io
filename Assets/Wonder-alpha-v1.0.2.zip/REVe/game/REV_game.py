import pygame
from typing import Any
from .Window import Window
from .Input import Input
from .Registry import Singleton
from ..utils import Sound

class REV_game(Singleton):

    """
        Provides the template for any REVe project. It's optional but offers a number of useful functionaity

        - it automatically instantiates a REVe.Window but allows you to customize it how ever you see fit
        - it also instantiates the REVe.Input for diverse input and custom key mapping customizability
        - and also allows you to pre-load any assets by automatically calling the load method right after initializing the REVe_game object 
    """
    Input = Input()
    Sounds = Sound.Sounds()
    Music = Sound.Music()

    def __init__(self,
                    caption: str,
                    icon_path: str | None = None,
                    display_size: list[int] = [320, 180],
                    screen_size: list[int] = [1280,720],
                    GPU_rendering: bool = False,
                    flags: Any = 0,
                    fps_cap: float = 60,
                    frag_path: str | None = None,
                    vert_path: str | None = None):
        
        super().__init__("Game")
        
        # Window setup
        self.RWO: Window = Window(
                    caption=caption,
                    icon_path=icon_path,
                    display_size=display_size,
                    screen_size=screen_size,
                    GPU_rendering=GPU_rendering,
                    flags=flags, fps_cap=fps_cap,
                    frag_path=frag_path,
                    vert_path=vert_path)
        self.window: pygame.Surface = self.RWO.screen
        self.display: pygame.Surface = self.RWO.display

        # Preloading Important stuff
        self.pre_load()

        # User Input setup
        self.Key_Input = self.Input.key.Input
        self.Mapped_Input = self.Input.map_Inputs
        self.Mouse = self.Input.mouse


    def new_shader(self, frag_path: str | None=None, vert_path: str | None=None):
        """
            Changes the shader program being used.

            Note [!] remember to change / update your uniforms.
        """
        self.RWO.render_object = self.RWO.mgl.get_render_obj(frag_path=frag_path, vert_path=vert_path)


    def pre_load(self):
        """
            Pre-load any necessary assets and all that. this function is called automatically after initializing (calling the __init__ method) the REVe Game 
        """
        pass


    def run(self):
        """
            Basically the games main loop
        """
        pass