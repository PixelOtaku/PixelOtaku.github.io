import pygame, time
from .Registry import Singleton
from pygame.math import Vector2 as vec2
from ..utils.math import flatten
from ..Defaults.Data import char_order

"""
    Classes that will make getting Input easier
"""

# State thingy
class Input_State:
    pressed: bool = False
    just_pressed: bool = False
    just_released: bool = False

    start_time: float = 0.0
    time_elapsed: float = 0.0

    def update(self):
        self.just_pressed = False
        self.just_released = False
        self.time_elapsed = time.time() - self.start_time if self.start_time != 0.0 else 0.0
    
    def press(self):
        self.pressed = True
        self.just_pressed = True
        self.start_time = time.time()
    
    def release(self):
        self.pressed = False
        self.just_released = True
        self.start_time = 0.0

# Mouse Input
class Mouse:
    pos: vec2 = vec2()
    move: vec2 = vec2()
    wheel_dir: float = 0.0

    buttons = {
        'mouse_right': Input_State(),
        'mouse_middle': Input_State(),
        'mouse_left': Input_State()
    }

    def press(self, button: int):
        self.buttons[button].press()

    def release(self, button: int):
        self.buttons[button].release()

    def scaled_pos(self, scale: list[float]) -> list[int]:
        return [self.pos.x * scale[0], self.pos.y * scale[1]]

    def update(self):
        mpos = vec2(pygame.mouse.get_pos())
        self.move = mpos - self.pos
        self.pos = mpos
        self.wheel_dir = 0
        for button in self.buttons.values():
            button.update()

# Key Board Input
class Key:
    supported_characters: list[str] = char_order
    Input: dict[str, Input_State] = {key: Input_State() for key in supported_characters}

# JoyStick Input
class JoyStick:
    pass



# --------- The Shit ----------

class Input(Singleton):
    # The Available Devices
    mouse = Mouse()
    key = Key()

    # Some Boilerplate stuff
    text_buffer_enabled: bool = False
    text_buffer: str = ''

    mapped_keys: dict[str, list[str]] = {}
    map_Inputs: dict[str, Input_State] = {}
    pressed: list = []

    Input_objs: list[Input_State] = flatten([list(key.Input.values()), list(map_Inputs.values())])

    # Other
    quitting: bool = False

    def __init__(self):
        super().__init__("Input")

    def set_keymap(self, key_map: dict[str, list[str]]={}):
        self.mapped_keys = key_map
        self.map_Inputs: dict[str, Input_State] = {key: Input_State() for key in list(self.mapped_keys.keys())}
        self.Input_objs = flatten([list(self.key.Input.values()), list(self.map_Inputs.values())])

    def get_pressed(self) -> list[str]:
        result: list[str] = [pygame.key.name(item) for item in self.pressed if item not in list(self.map_Inputs.keys())]
        return result

    def update(self):
        [input_obj.update() for input_obj in self.Input_objs]
        self.mouse.update()

        for event in pygame.event.get():
            if event.type == pygame.QUIT:
                self.quitting = True

            if event.type == pygame.MOUSEBUTTONDOWN:
                if event.button == 3:
                    self.mouse.press('mouse_right')
                    self.pressed.append('mouse_right')
                if event.button == 2:
                    self.mouse.press('mouse_middle')
                    self.pressed.append('mouse_middle')
                if event.button == 1:
                    self.mouse.press('mouse_left')
                    self.pressed.append('mouse_left')

            if event.type == pygame.MOUSEBUTTONUP:
                if event.button == 3:
                    self.mouse.release('mouse_right')
                    self.pressed.remove('mouse_right')
                if event.button == 2:
                    self.mouse.release('mouse_middle')
                    self.pressed.remove('mouse_middle')
                if event.button == 1:
                    self.mouse.release('mouse_left')
                    self.pressed.remove('mouse_left')

            
            if event.type == pygame.MOUSEWHEEL:
                self.mouse.wheel_dir = event.y

            if event.type == pygame.KEYDOWN:

                # For the text and stuff
                if self.text_buffer_enabled:
                    if event.key != pygame.K_BACKSPACE and event.unicode in self.key.supported_characters:
                        self.text_buffer = self.text_buffer + event.unicode
                    elif event.key == pygame.K_BACKSPACE:
                        self.text_buffer = self.text_buffer[:-1]
                    
                
                if event.unicode in self.key.Input:
                    self.key.Input[event.unicode].press()
                    self.pressed.append(event.key)
                else:
                    self.pressed.append(event.key)

            if event.type == pygame.KEYUP:
                if event.unicode in self.key.Input:
                    self.key.Input[event.unicode].release()
                    self.pressed.remove(event.key)
                else:
                    self.pressed.remove(event.key)

        for key, mapping in self.mapped_keys.items():
            if (set(mapping) & set(self.pressed)) and key not in self.pressed:
                self.map_Inputs[key].press()
                self.pressed.append(key)
            elif not (set(mapping) & set(self.pressed)) and key in self.pressed:
                self.map_Inputs[key].release()
                self.pressed.remove(key)
            else:
                pass
