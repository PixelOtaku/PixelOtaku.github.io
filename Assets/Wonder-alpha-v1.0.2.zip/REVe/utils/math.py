import math
from math import pi

"""
    A bunch of math related functions that allow you to calculate a bunch of stuff like the angle between points, 
"""


# Math Related functions

def distance(pt1: list[float], pt2: list[float]) -> float:
    """
        Gives you the distance in pixels between two points
    """

    return ((pt2[0] - pt1[0])**2 + (pt2[1] - pt1[1])**2)**0.5


def get_velocity_vector(pt1: list[float], pt2: list[int]) -> float:
    """
        gives you the direction to a certain point as a normalized vector.
    """

    angl: float = get_angle_d(pt1, pt2)
    vx: float = round(math.cos(angl*(pi/180)), 4)
    vy: float = round(math.sin(angl*(pi/180)), 4)

    return [vx, vy]


def get_angle_r(pt1: list[float], pt2: list[float]) -> float:
    """
        Gives you the angle between two points in Radians
    """

    return math.atan2((pt2[1] - pt1[1]), (pt2[0] - pt1[0]))


def get_angle_d(pt1: list[float], pt2: list[float]) -> float:
    """
        Gives you the angle between two points in Degrees
    """

    return math.atan2((pt2[1] - pt1[1]), (pt2[0] - pt1[0])) * (180 / math.pi)


def clamp(val: float, min_val: float, max_val: float) -> float:

    """
        This function clamps the value inbetween a minimum value and a maximum value
    """

    return max(min_val, min(val, max_val))


def Interpolate_1D(init_point: float, target_point: float, factor: float) -> float:
    """
        This function will allow you to interpolate between 2 values, just provide a starting point (number) as well as a target / end value.
        The interpolate factor is supposed to be a number between 0.0 and 1.0. if the factor is 0.0 then the function returns the first number.
        If the factor is 1.0, then the function returns the end value. if the factor is inbetween 0.0 and 1.0 then the function returns a value
        between the start and end.
    """

    return init_point + (target_point - init_point) * clamp(factor)


def Interpolate_2D(init_pt: list[float], target_pt: list[float], factor: float) -> list[float]:
    """
        This fuction uses the Interpolate_1D function to Interpolate between two points
    """

    return (Interpolate_1D(init_pt[0], target_pt[0], factor), Interpolate_1D(init_pt[1], target_pt[1], factor))


def flatten(iterable: list) -> list:

    """
        This function allows you to flatten a 2D array / list into a 1D array / list.
        example:
            - [[0,1], [2,3], [4,5], [6,7]] -> [0,1,2,3,4,5,6,7]
    """

    result: list = [item for lst in iterable for item in lst]
    return result


def normalize(vector: list[float]) -> list[float]:
    """
        Normalizes a given vector, or simple put changes the vectors x and y till it has a magnitude of 1 and still maintains it's direction.
    """

    angl: float = get_angle_r((0,0), vector)
    if distance((0,0), vector) == 0.0:
        return [0.0, 0.0]
    else:
        return [round(math.cos(angl), 10), round(math.sin(angl), 10)]


def get_vector(x_neg: bool=False, x_pos: bool=False, y_neg: bool=False, y_pos: bool=False, normalized: bool=False) -> list[int]:
    """
        This takes in 4 directions and returns a vector. The last parameter influences whether or not it gets normalized
    """

    pt = (-x_neg + x_pos, -y_neg + y_pos)
    if normalized:
        result = normalize(pt)
    else:
        result = pt
    return result


def get_box_pts(pt1: list[int], pt2: list[int]) -> list[list[int]]:
    """
        Gets the coordinates of all the points in a box created by two points, the topleft and bottom right point.
    """
    #return [[x, y] for y in range(min(pt1[1], pt2[1]), max(pt1[1], pt2[1]) + 1) for x in range(min(pt1[0], pt2[0]), max(pt1[0], pt2[0]) + 1)]
    return [[x, y] for y in range(pt1[1], pt2[1] + 1) for x in range(pt1[1], pt2[1] + 1)]