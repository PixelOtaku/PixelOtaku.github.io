import pygame, os
from os.path import join
from ..game.Registry import Singleton

# Sounds
class Sounds(Singleton):
    """
        REVe's Global Sound Object. Once Instantiated can be used by every other Singleton Element in the Game.
    """
    sounds: dict[str, pygame.mixer.Sound] = {}
    supported: list[str] = ['wav', 'mp3', 'ogg']

    def __init__(self):
        """
            Initialize the REVe Sound object.
        """

        super().__init__('Sound')
        pygame.mixer.init()
        pygame.mixer.set_num_channels(64)

    def load_from_path(self, sound_path: str) -> None:
        """
            Load all the supported sound files from a given folder
        """
        for name in os.listdir(sound_path):
            if name.split('.')[-1] in self.supported:
                self.sounds[name.split('.')[0]] = pygame.mixer.Sound(join(sound_path, name))

    def play(self, sound_id: str, volume: float=1.0, pan: float=0.0, loops: int=0) -> None:
        """
            Play one of the imported sounds.
        """
        if sound_id in self.sounds.keys():
            channel = self.sounds[sound_id].play(loops)
            if pan != 0.0:
                volumes = (1 - (pan + 1) / 2, (pan + 1) / 2)
                volume *= 1 - abs(pan) * 0.9
                channel.set_volume(volumes[0] * volume, volumes[1] * volume)
            else:
                channel.set_volume(volume)



# Music
class Music(Singleton):
    """
        REVe's Global Music Object. Once Instantiated can be used by every other Singleton Element in the Game.
    """
    music: list[str] = []
    currently_playing: str | None = None
    sound_path: str = ''
    supported: list[str] = ['wav', 'mp3', 'ogg']

    def __init__(self):
        """
            Initialize the REVe Music Object.
        """
        super().__init__('Music')
        pygame.mixer.init()
        self.manager = pygame.mixer.music

    def play(self, music_id: str, volume: float=1.0, loops: int=0, Inturupt: bool=False):
        """
            Play Music using pygames mixer.music.
        """
        if self.currently_playing == None:
            self.manager.load(join(self.sound_path, music_id))
            self.manager.set_volume(volume)
            self.manager.play(loops)
            self.currently_playing = music_id

        elif self.currently_playing != None:
            if Inturupt:
                self.manager.stop()
                self.manager.load(join(self.sound_path, music_id))
                self.manager.set_volume(volume)
                self.manager.play(loops)
                self.currently_playing = music_id
            else:
                return None

    def update(self):
        """
            Update Music object.
        """
        if self.manager.get_busy():
            pass
        else:
            self.currently_playing = None