import pygame, time
from typing import Callable, Any
pygame.init()

debug_font: pygame.font.Font = pygame.font.Font(None, 18)

def debug(surf: pygame.Surface, text:str, pos: tuple[int]=(10, 10), color:tuple[int]=(255,255,255)) -> None:

    """
        This function allows you to display important data on a specified surface, i find this more efficient (performance and debugging wise) compared to printing the needed result
    """

    debug_surf: pygame.Surface = debug_font.render(str(text), True, color)
    debug_rect: pygame.Rect = debug_surf.get_rect(topleft = pos)
    surf.blit(debug_surf, debug_rect)


def time_it(func: Callable[[Any], Any], params: list[Any] | None=None) -> float:
    """
        Use the following function to fin out how much time a function takes to do the stuff
    """

    start_time: float = time.time()
    if len(params) > 0:
        func(*params)
    else:
        func()
    return time.time() - start_time