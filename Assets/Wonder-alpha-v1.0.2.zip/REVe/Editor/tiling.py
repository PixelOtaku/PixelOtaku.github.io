import pygame, os
from typing import Any
from os.path import join
from ..utils.file_utils import read_f
from ..utils.gfx import clip

"""
    A module filled with tileset and tilemap stuff. Made mainly for use with the REVeit map editor.
"""

layer = int
key = str

class Tileset:

    """
        Tilesets are 'essential' for grouping related tileset images or tileset objects for your game as they allow you to import all the tiles from an image specified using a path
        or all the images from a folder if needed and group them.

        Methods:

            - .from_image: Imports all the tile images from an image as well as the .reveconf (REVe config) file associated with it if it exists.
            - .from_folder: Imports all the tile images from a folder as well as the .reveconf file associated with it if it exists.
    """

    @staticmethod
    def from_image(img_path: str, rows_and_cols: list[int], tile_size: list[int]=(16,16), color_key: list[int] | None=None, topleft_offset: list[int]=(1,1)) -> list[Any]:

        """
            Clips every tile image from a given image and stores them in the tileset.

            returns [tileset_name: str, tileset_dictionary: dict[str | int, pygame.Surface], tile_config: dict[str | int, Any] | None]
        """

        # Clip all the tiles from the provided image
        og_surf: pygame.Surface = pygame.image.load(img_path).convert_alpha()
        handle_surf: pygame.Surface = og_surf.copy()
        img_count: int = 0

        imgs: dict[str|int, pygame.Surface] = {}
        for y in range(rows_and_cols[1]):
            for x in range(rows_and_cols[0]):
                topleft: list[int] = (((tile_size[0] + 1) * x) + 1, ((tile_size[1] + 1) * y) + 1)
                imgs[img_count] = clip(handle_surf, pygame.Rect(topleft, tile_size), color_key)
                img_count += 1

        # Get the config of the tiles
        img: str = img_path.split('\\')[-1] if '\\' in img_path else img_path.split('/')[-1]
        name = img.split('.')[0]
        img = f"{name}.revconf"
        config_path: str = join(*img_path.split('\\')[:-1], img) if '\\' in img_path else join(*img_path.split('/')[:-1], img)
        try:
            config: dict[str | int, Any] | None = eval(read_f(config_path))
        except FileNotFoundError:
            config: dict[str | int, Any] | None = None

        return [name, imgs, config]

    @staticmethod
    def from_folder(img_path: str, color_key: list[int] | None=None) -> list[Any]:
        
        """
            Import tile images from a given folder as a tileset.

            returns [tileset_name: str, tileset_dictionary: dict[str | int, pygame.Surface], tile_config: dict[str | int, Any] | None]
        """

        set_name: str = img_path.split('\\')[-1] if '\\' in img_path else img_path.split('/')[-1]
        name = set_name
        imgs: dict[str, pygame.Surface] = {}

        for image_name in os.listdir(img_path):
            if '.png' in image_name:
                imgs[image_name.split('.')[0]] = pygame.image.load(join(img_path, image_name)).convert_alpha()
                if color_key != None:
                    imgs[image_name.split('.')[0]].set_colorkey(color_key)

        config_path: str = join(*img_path.split('\\'), f"{set_name}.revconf") if '\\' in img_path else join(*img_path.split('/')[:-1], f"{set_name}.revemp")
        try:
            config = eval(read_f(config_path))
        except FileNotFoundError:
            config = None

        return [name, imgs, config]
    
    
class Tilemap:
    """
        Useful functionality related to the maps made using REVe's very own map editor, REVeit editor
    """

    @staticmethod
    def load(tile_map_path: str) -> dict[layer, dict[str, dict[str, Any]]]:
        """
            Load a .revemp file containing all the tiledata as a dict[layer, dict[str, dict[str, Any]]]

            Note [!] I suspect the method to be rather slow so try using not so often or at least try to only use it at the begin during the pre-loading phase
        """

        return eval(read_f(tile_map_path))
    
    @staticmethod
    def search(tile_map: dict[layer, dict[str, dict[str, Any]]], query: Any) -> list[dict[str, Any]]:
        """
            This function takes a query and searches though the tilemap provided then returns a list filled with dictionaries containing the layer,
            the tile, as well as the other attributes of the tiles that match the query.

            Note that the bigger the tilemap the slower the algorithm as it operates at O(n^2) time complexity so it's better for small maps or for use outside the game loop
        """

        results: list[dict[str, Any]] = []

        for l in tile_map.keys():
            for t in tile_map[l].keys():
                tile = tile_map[l][t]
                if query in list(tile.values()):
                    dct = {
                        'layer': l,
                        'tile': t,
                        'properties': tile
                    }
                    results.append(dct)

        return results
    
    @staticmethod
    def setup(map: dict[str, dict[str, Any]]) -> list[Any]:
        """
            Still in development.
        """
        pos_list = []

        for tile in map.keys():
            for layer in map[tile].keys():
                lookup = map[tile][layer]

                pos_list.append(lookup['Pos'])

        return pos_list