import logging
import sys

# Logging set up
logging.basicConfig(filename='error.log', level=logging.ERROR)

# Debug func.
def print_red(text: str):
    print("\033[1;31m" + text + "\033[0m")

# Exception class
class Err(Exception):
    def __init__(self, message: str):
        self.msg: str = message
        super().__init__(message)

    def LOG(self):
        logging.error(self.msg)
        print_red(self.msg)