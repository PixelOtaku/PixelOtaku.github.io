import pygame
from typing import Any
from pygame.math import Vector2 as vec2

"""
   The Various Player Controllers in REVe, including a platformer player controller, a top-down player controller and some with pysics support 
"""

class Character_Body(pygame.sprite.Sprite):
   """
      The basic Blueprint for REVe entities.
   """
   def __init__(self, img: pygame.Surface, pos: list[int], groups: pygame.sprite.Group | None=None, blit_layer: int=0, properties: dict[str, str]={}, tilesize: int=16):
      super().__init__(groups)

      # Boilerplate
      self.image: pygame.Surface = img
      self.rect: pygame.Rect = self.image.get_rect(topleft = (pos[0], pos[1] - (self.image.get_height() - tilesize)))
      self.hitbox: pygame.Rect = self.rect.copy()
      self.old_rect: pygame.Rect = self.hitbox.copy()
      self.blit_layer: int = blit_layer
      self.properties: dict[str, str] = properties

      self.name: str = self.__class__.__name__
      self.groups: list[pygame.sprite.Group] = groups
      self.spawn_pos: list[int] = pos
      self.rect_offset: vec2 = vec2()

      # Collisions
      self.neighbors: list[Any] = []

      # Movement
      self.velocity: vec2 = vec2()

   def set_hitbox(self, offset: list[int], size: list[int]) -> None:
      """
         Quickliy fix the hitbox.
      """
      self.rect_offset = vec2(offset[0], offset[1])
      pos = (self.rect.x + self.rect_offset.x, self.rect.y + self.rect_offset.y)
      self.hitbox = pygame.Rect(pos , size)
      self.old_rect = self.hitbox.copy()

   def collision(self, axis: str):
        """
            Check for collision on one axis. If you just moved horizontally (along the x axis) call the collision method and pass in 'horizontal' to check and resolve collisions, same goes for the vertical movement (along the y axis), just call the collision method then pass in 'vertical'.
        """
        for sprite in self.neighbors:
            if self.hitbox.colliderect(sprite.rect):
                if axis == 'horizontal':
                    if self.hitbox.left <= sprite.hitbox.right and self.old_rect.left >= sprite.old_rect.right:
                        self.hitbox.left = sprite.hitbox.right
                    if self.hitbox.right >= sprite.hitbox.left and self.old_rect.right <= sprite.old_rect.left:
                        self.hitbox.right = sprite.hitbox.left

                elif axis == 'vertical':
                    if self.hitbox.top <= sprite.hitbox.bottom and self.old_rect.bottom >= sprite.old_rect.bottom:
                        self.hitbox.top = sprite.hitbox.bottom
                        self.velocity.y = 1
                    if self.hitbox.bottom > sprite.hitbox.top and self.old_rect.bottom <= sprite.old_rect.top:
                        self.hitbox.bottom = sprite.hitbox.top
