import pygame, moderngl
from array import array
from .render_obj import Render_Object
from ..utils.file_utils import read_f
from ..Defaults.Data import default_frag_shader, default_vert_shader

mgl_Tex = moderngl.Texture

class MGL:

    """
        My custom modernGL API. allows you to create render objects which are what actually pass instructions to the GPU.
    """

    def __init__(self):

        """
            Instantiate the mGL API
        """

        self.ctx: moderngl.Context = moderngl.create_context()

        self.quad_buffer = self.ctx.buffer(data=array('f', [
        #pos(x,y), uv_coord(x,y)
        -1.0, 1.0, 0.0, 0.0,  # topleft
         1.0, 1.0, 1.0, 0.0,  # topright
        -1.0, -1.0,0.0, 1.0, # bottomleft
         1.0, -1.0, 1.0, 1.0,  # bottomright
        ]))

        self.Default_ro: bool = False
        self.render_obj: Render_Object = self.get_render_obj()

        self.frame_tex = moderngl.Texture | None


    def get_render_obj(self, frag_path: str | None=None, vert_path: str | None=None) -> Render_Object:

        """
            returns a new Render Object
        """

        self.Default_ro = True if frag_path == None and vert_path == None else False
        frag_path = default_frag_shader if frag_path == None else read_f(frag_path)
        vert_path = default_vert_shader if vert_path == None else read_f(vert_path)

        return Render_Object(self.ctx, self.quad_buffer, frag_path, vert_path)
    

    def surf_2_tex(self, surf: pygame.Surface) -> moderngl.Texture:

        """
            This is a functions that changes pygame.Surfaces to moderngl.Textures
        """

        channels = 4
        new_tex = self.ctx.texture(surf.get_size(), channels)
        new_tex.filter = (moderngl.NEAREST, moderngl.NEAREST)
        new_tex.swizzle = 'BGRA'
        new_tex.write(surf.get_view('1'))
        return new_tex