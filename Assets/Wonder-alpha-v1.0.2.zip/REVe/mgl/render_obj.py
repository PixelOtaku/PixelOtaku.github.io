import pygame, moderngl
from typing import Any
from ..Defaults.Data import default_vert_shader, default_frag_shader

class Render_Object:

    """
        A render object carries a modernGL program as well as the VertexArray object (vao) enabling it to pass uniforms as well as instructions to the GPU.
    """

    def __init__(self, ctx: moderngl.Context, buffer: moderngl.Buffer, frag_shader: str | None=None, vert_shader: str | None=None, vao_args: list[str]=['2f 2f', 'vert', 'texcoord']):

        """
            Instantiate the mGL API render object
        """

        self.ctx: moderngl.Context = ctx
        self.buffer: moderngl.Buffer = buffer
        self.vao_args: list[str] = vao_args

        self.frag_shader: str = default_frag_shader if frag_shader == None else frag_shader
        self.vert_shader: str = default_vert_shader if vert_shader == None else vert_shader

        self.program: moderngl.Program = self.ctx.program(vertex_shader=self.vert_shader, fragment_shader=self.frag_shader)
        self.vao: moderngl.VertexArray = self.ctx.vertex_array(self.program, [(self.buffer, *self.vao_args)])

        self.dest: moderngl.Texture | None

        self.temp_textures: list[moderngl.Texture] = []

    
    def update(self, uniforms: dict[str, moderngl.Texture | Any]={}):
        
        """
            Feeds uniforms into the GPU and updates them the next time it's called
        """

        tex_id: int = 0
        for uniform in uniforms.keys():
            if type(uniforms[uniform]) == moderngl.Texture:
                # Bind uniform to tex
                uniforms[uniform].use(tex_id)

                # Specify ID as uniform target
                self.program[uniform] = tex_id
                tex_id += 1
            else:
                self.program[uniform] = uniforms[uniform]


    def parse_uniforms(self, uniforms: dict[str, pygame.Surface | Any]={}) -> dict[str, moderngl.Texture | Any]:

        """
            This function goes through every uniform and checks for pygame.Surfaces then turns them into moderngl.Textures when found
        """

        for key, value in uniforms.items():
            if type(value) == pygame.Surface:
                tex: moderngl.Texture = self.surf_2_tex(value)
                uniforms[key] = tex
                self.temp_textures.append(tex)
        return uniforms


    def render(self, display: pygame.Surface, uniforms: dict[str, Any]={}):
        
        """
            Pass the uniforms to the GPU.
        """

        self.dest = self.ctx.screen
        self.dest.use

        self.parse_uniforms(uniforms=uniforms)
        self.update(uniforms=uniforms)
        self.vao.render(moderngl.TRIANGLE_STRIP)

        # Cleanup
        self.dest.release()
        for tex in self.temp_textures:
            tex.release()


    def surf_2_tex(self, surf: pygame.Surface) -> moderngl.Texture:

        """
            This is a functions that changes pygame.Surfaces to moderngl.Textures
        """

        channels = 4
        new_tex = self.ctx.texture(surf.get_size(), channels)
        new_tex.filter = (moderngl.NEAREST, moderngl.NEAREST)
        new_tex.swizzle = 'BGRA'
        new_tex.write(surf.get_view('1'))
        return new_tex
    

    def texture_update(self, tex: moderngl.Texture, surf: pygame.Surface) -> moderngl.Texture:

        """
            Copies pixel data from a pygame.Surface onto a moderngl.Texture, effectively craeting a version of the pyga,e.Surface that can be used by the GPU.
        """

        tex.write(surf.get_view('1'))
        return tex