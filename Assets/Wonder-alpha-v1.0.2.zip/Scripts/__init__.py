"""
    Scripts for test platformer.
"""

from .Layout import *
from .Entities import *