from .Config import *
from .Entities import *
from REVe.game.Input import Input
from REVe.utils.misc import Custom_Font, Button

# The Scene manager for the game.
class Level(REVe.Layout):
    debug: bool = False

    def __init__(self, map: str, id: str='Scene'):
        super().__init__(id)

        self._map = map

        # Boilerplate
        self.Surface: pygame.Surface = self.Registry['Window'].display
        self.map: dict[str, dict[str, dict[str, Any]]] = REVe.Tilemap.load(map)
        self.IO: Input = self.Registry['Input']

        # Graphics / Animations.
        self.gfx: dict[str, dict[str, pygame.Surface]] = self.Registry['Game'].gfx
        self.anims: dict[str, dict[str, dict[str, pygame.Surface]]] = self.Registry['Game'].animations
        self.glow_img: pygame.Surface = self.Registry['Game'].glow_img
        self.particles: dict[str, dict[str, pygame.Surface]] = self.Registry['Game'].particles

        # Sprite Groups
        self.Camera: Cam = Cam(Surface=self.Surface, background_img=self.Registry['Game'].BG_img)
        self.PManager: Patricle_Manager = Patricle_Manager(surface=self.Surface, particle_images=self.particles)
        self.Collide: pygame.sprite.Group = pygame.sprite.Group()

        # Search for the player.
        player_query: list[dict[str, Any]] = REVe.Tilemap.search(self.map, 'Player')
        if player_query:
            # Extract the necessary data.
            lookup = player_query[0]['properties']
            LAYER: int = lookup['Layer']
            POS: list[float] = list(vec2(lookup['Pos']) * TILESIZE)
            PROPERTIES: dict[str, str] = lookup['Properties']

            # Create Player.
            self.Player = Player(self.anims['Player'], POS, [self.Camera], self.get_neighbors, self.remove_sprite, self.Camera.Screen_shake, LAYER)
            self.Player.IO = self.IO
            self.Player.SO = self.Registry['Sound']
            self.Player.properties = PROPERTIES
        else:
            REVe.Err(f"Player not found in {map}")

        # Other Stuff
        self.Sprites: dict[layer, dict[str, Any]] = self.setup()

        # Camera stuff
        self.Cam_target: Any = self.Player

        # The Heads Up Display
        self.HUD: HUD = HUD()


    def setup(self) -> dict[str, Any]:
        Static_Sprites: dict[str, Any] = {}

        for tile in self.map.keys():
            for layer in self.map[tile].keys():
                lookup = self.map[tile][layer]

                # Getting The data from the REVe map.
                LAYER: int = lookup['Layer']
                POS: list[float] = list(vec2(lookup['Pos']) * TILESIZE)
                IMG: str = lookup['Image']
                SET: str = lookup['Set']
                PROPERTIES: dict[str, str] = lookup['Properties']

                if LAYER not in Static_Sprites:
                    Static_Sprites[LAYER] = {}

                # Spawning Sprites and adding their data to somewhere rather accessible
                if SET == 'Decor':
                    if IMG == 'lantern':
                        sprite = PGlowy_Tile(self.PManager.add, self.gfx[SET][IMG], POS, [self.Camera], glow_color=(20,30,40), glow_img=self.glow_img)
                        sprite.name = IMG
                        sprite.properties = PROPERTIES
                        Static_Sprites[LAYER][str(POS)] = sprite

                    if IMG == 'flag':
                        sprite = Animated_Tile(self.anims['Flag'], 9, POS, [self.Camera], LAYER)
                        sprite.name = IMG
                        sprite.properties = PROPERTIES
                        Static_Sprites[LAYER][str(POS)] = sprite

                    if IMG == 'door':
                        sprite = Door(self.__init__, self.gfx[SET][IMG], POS, [self.Camera], LAYER)
                        sprite.name = IMG
                        sprite.properties = PROPERTIES
                        sprite.player = self.Player
                        Static_Sprites[LAYER][str(POS)] = sprite

                    else:
                        sprite = Static_Tile(self.gfx[SET][IMG], POS, [self.Camera], LAYER)
                        sprite.name = IMG
                        sprite.properties = PROPERTIES
                        Static_Sprites[LAYER][str(POS)] = sprite

                if SET == 'Collectable':
                    if IMG == 'G_coin':
                        sprite = Animated_Tile(self.anims['G_coin'], 8, POS, [self.Camera], LAYER)
                        sprite.set_hitbox([5,4], [6,8])
                        sprite.name = IMG
                        sprite.properties = PROPERTIES
                        Static_Sprites[LAYER][str(POS)] = sprite

                    if IMG == 'S_coin':
                        sprite = Animated_Tile(self.anims['S_coin'], 8, POS, [self.Camera], LAYER)
                        sprite.set_hitbox([5,4], [6,8])
                        sprite.name = IMG
                        sprite.properties = PROPERTIES
                        Static_Sprites[LAYER][str(POS)] = sprite

                if SET == 'Grass':
                    sprite = Static_Tile(self.gfx[SET][IMG], POS, [self.Camera], LAYER)
                    sprite.name = IMG
                    sprite.properties = PROPERTIES
                    Static_Sprites[LAYER][str(POS)] = sprite

                if SET == 'Stone':
                    sprite = Static_Tile(self.gfx[SET][IMG], POS, [self.Camera], LAYER)
                    sprite.name = IMG
                    sprite.properties = PROPERTIES
                    Static_Sprites[LAYER][str(POS)] = sprite

                if SET == 'Enemies':
                    if IMG == 'Drone':
                        sprite = Drone(self.anims['Drone'], self.anims['Projectile1'], POS, [self.Camera], LAYER)
                        sprite.player = self.Player
                        sprite.properties = PROPERTIES

        return Static_Sprites


    def get_neighbors(self, layer: int, position: list[int]) -> list[Any]:
        """
            Get all the neighboring Sprites around the position. It only gets the sprites within the same blit_layer 
        """
        grid_pos: vec2 = vec2(position)//TILESIZE
        neigbors: list[str] = [self.Sprites[layer][f"{[(x-1+grid_pos.x)*TILESIZE, (y-1+grid_pos.y)*TILESIZE]}"] for y in range(3) for x in range(3) if (x,y) != (1,1) if f"{[(x-1+grid_pos.x)*TILESIZE, (y-1+grid_pos.y)*TILESIZE]}" in self.Sprites[layer]]
        return neigbors


    def remove_sprite(self, layer: int, position: list[int]) -> None:
        """
            Remove from the Static Sprite dictionary.
        """
        if str(position) in self.Sprites[layer]:
            target = self.Sprites[layer][str(position)]
            del self.Sprites[layer][str(position)]
            target.kill()


    def update(self):
        if not self.HUD.pause_menu_active:
            # Update The Camera
            self.Camera.follower_camera(self.Player.hitbox, TILESIZE*7, self.Registry['Window'].dt)
            self.Camera.update(self.Registry['Window'].dt)

            self.Camera.Draw_Platformer()
            if self.debug:
                self.Camera.Draw_Hitboxes()
        
            # Draw particles
            self.PManager.emit(offset=[self.Camera.origin.x, self.Camera.origin.y], dt=self.Registry['Window'].dt)

        # Update The HUD
        self.HUD.update()



# Particle Manager
class Patricle_Manager:
    def __init__(self, surface: pygame.Surface, particle_images: dict[str, dict[str, pygame.Surface]]):
        self.Surface: pygame.Surface = surface
        self.particle_imgs: dict[str, dict[str, pygame.Surface]] = particle_images
        self.particle_list: list[Any] = []

    def emit(self, offset: list[int], dt: float):
        """
            Emit particles and execute their different behaviours.
        """
        for index, particle in enumerate(self.particle_list):
            match particle[0]:
                case '1': self.Behaviour_1(index, offset, dt)
                case _ : pass

    def add(self, typ: str, pos: list[int], *args):
        """
            Add a particle to the particle list.
        """
        match typ:
            case '1':
                img, velocity, speed, anim_speed = args
                self.particle_list.append([typ, pos, 0, img, velocity, speed, anim_speed])
            case _ : pass

    def Behaviour_1(self, index: int, offset: list[int], dt: float):
        # Get necessary data.
        img: str = self.particle_list[index][3]
        img_index: float = self.particle_list[index][2]
        velocity: list[int] = self.particle_list[index][4]
        pos = [self.particle_list[index][1][0] + velocity[0], self.particle_list[index][1][1] + velocity[1]]
        speed: int = self.particle_list[index][5]
        anim_speed: int = self.particle_list[index][6]

        if int(img_index) == len(list(self.particle_imgs[img].values())) - 1:
            # Delete the particle.
            self.particle_list.pop(index)
        else:
            # Draw
            REVe.blit(self.Surface, self.particle_imgs[img][list(self.particle_imgs[img].keys())[int(img_index)]], (int(pos[0] - offset[0]), int(pos[1] - offset[1])), 0, 1, True)

            # Update
            self.particle_list[index][1] = pos
            self.particle_list[index][2] += anim_speed * dt



# A Camera Specific to this Game
class Cam(REVe.Camera):
    def __init__(self, Surface: pygame.Surface, background_img: pygame.Surface, tile_size: int = 16):
        super().__init__(Surface, tile_size)

        self.BG: pygame.Surface = background_img

    def Draw_Platformer(self):
        """
            Draw all the sprites, only the ones visible to the Camera.
        """
        self.Surface.blit(self.BG)

        for sprite in sorted(self.sprites(), key = lambda x: x.blit_layer):
            tl = vec2(sprite.rect.topleft) - vec2(sprite.rect_offset) - self.origin
            ct = vec2(sprite.rect.center) - vec2(sprite.rect_offset) - self.origin
            if max(-self.tile_size, min(tl.x, self.Surf_size.x)) == tl.x and max(-self.tile_size, min(tl.y, self.Surf_size.y)) == tl.y:
                REVe.blit(self.Surface, sprite.image, tl)

                if hasattr(sprite, 'glow_img'):
                    if sprite.glow_img != None:
                        REVe.blit(self.Surface, sprite.glow_img, ct, center=True, flags=pygame.BLEND_RGBA_ADD)

    def Draw_Hitboxes(self):
        """
            Draw hitboxes of all visible sprites for debbuging sakes.
        """
        for sprite in sorted(self.sprites(), key = lambda x: x.blit_layer):

            tl = vec2(sprite.rect.topleft) - self.origin
            if max(-self.tile_size, min(tl.x, self.Surf_size.x)) == tl.x and max(-self.tile_size, min(tl.y, self.Surf_size.y)) == tl.y:
                pygame.draw.rect(self.Surface, (200,200,50), pygame.Rect(tl, sprite.hitbox.size), 1)



# The HUD's sections
class Section:
    """ An Object containing it's own Surface as well as a Rect """
    def __init__(self, size: vec2, pos: vec2, color: list[int]=[255,255,255], visible: bool = True):
        self.color: list[int] = color
        self.size: vec2 = size
        self.surf: pygame.Surface = pygame.Surface((size))
        self.rect: pygame.Rect = pygame.Rect(pos, size)
        self.pos: vec2 = pos

        self.visible: bool = visible
        self.clear()

    def clear(self):
        """ Clear the Surface of the Section (fill it with it's origional color). """
        self.surf.fill((self.color))

# The HUD for the Game.
class HUD(REVe.HUD):
    def __init__(self):
        super().__init__()

        # Boilerplate.
        self.DFont = Custom_Font(font_path=FONT_PATH, color=(200,50,50), scale=2)
        self.TFont = Custom_Font(font_path=FONT_PATH, color=(200,200,200), scale=3)
        self.Font1 = Custom_Font(font_path=FONT_PATH, color=(200,200,200), scale=2)

        # Mechanics
        self.current_Time: float = 0.0

        self.pause_menu_active: bool = False

        # Sections
        self.Sections: dict[str, Section] = {
            'Main': Section(
                size=vec2(1240,680),
                pos=vec2(20,20),
                color=(210,200,180),
                visible=False
            )
        }

        # Buttons
        self.Buttons: dict[str, Button] = {
            'Pause': Button(
                surf = self.Surface,
                text = "MENU",
                font_path=FONT_PATH,
                rect = (24,16),
                pos = (16,16),
                max_elev = 4,
                text_offset=(2,2),
                border=4
                )
            }
        
        # Other


    def draw_stuff(self):
        pass


    def draw_text(self):
        self.DFont.render(self.Surface, f"FPS: {self.Registry['Window'].current_fps:.2f}", (1180, 10))


    def update_buttons(self):
        for button in self.Buttons.keys():
            self.Buttons[button].update()
        
        if self.Buttons['Pause'].active:
            self.pause_menu_active = not self.pause_menu_active
            self.Sections['Main'].visible = not self.Sections['Main'].visible


    def update(self):
        # Clear All the Sections
        for section in self.Sections.keys():
            self.Sections[section].clear()

        # Update Sections
        self.draw_stuff()
        self.draw_text()
        self.update_buttons()

        # Draw sections
        for section in self.Sections.keys():
            if self.Sections[section].visible:
                self.Surface.blit(self.Sections[section].surf, self.Sections[section].rect)