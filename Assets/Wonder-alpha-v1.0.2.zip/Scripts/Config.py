import REVe, pygame, random
from os.path import join
from pygame.math import Vector2 as vec2
from typing import Any, Callable

# Display config
SCREEN_SIZE: tuple[int] = (1280, 720)
DISPLAY_SIZE: tuple[int] = (320, 180)

# Level stuff
TILESIZE: int = 16

Maps: dict[str, str] = {
    'map1': join('Assets', 'Maps', 'map1.revemp'),
    'map2': join('Assets', 'Maps', 'map2.revemp')
}

# Font stuff
FONT_PATH: str = join('REVe', 'Defaults', 'Default_Assets', 'blox.png')

# Default path
DEFAULT: str = join('REVe', 'Defaults', 'Default_Assets')

# Other
layer = int