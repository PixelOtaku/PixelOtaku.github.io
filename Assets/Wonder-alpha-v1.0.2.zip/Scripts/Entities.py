from REVe.Entities.Tiles import Tile
from REVe.Entities.Player_controllers import Character_Body
import REVe.utils
from .Config import *
from pygame.math import Vector2 as vec2
from REVe.game.Input import Input
from REVe.utils.misc import Timer



# Tiles (General).

# ----- Static Tiles -----
class Static_Tile(Tile):
    def __init__(self, img: pygame.Surface, pos: list[int], groups: pygame.sprite.Group | None=None, blit_layer: int=0):
        super().__init__(img, pos, groups, blit_layer, TILESIZE)


# ----- Glowy Tiles -----
class Glowing_Tile(Tile):
    def __init__(self, img: pygame.Surface, pos: list[int], groups: pygame.sprite.Group | None=None, glow_radius: int=32, glow_color: int=(20,20,20), blit_layer: int=0, glow_img: pygame.Surface=pygame.Surface((TILESIZE, TILESIZE))):
        super().__init__(img, pos, groups, blit_layer, TILESIZE)

        # Setup glow image
        self.glow_img: pygame.Surface = pygame.Surface(glow_img.get_size())
        self.glow_img.fill(glow_color)
        REVe.blit(self.glow_img, glow_img, (0,0), flags=pygame.BLEND_RGBA_MULT)
        self.glow_img = pygame.transform.scale(self.glow_img, (glow_radius*2, glow_radius*2))


# ----- Animated tile -----
class Animated_Tile(Tile):
    def __init__(self, animation: dict[str, pygame.Surface], anim_speed: float, pos: list[int], groups: pygame.sprite.Group | None=None, blit_layer: int=0):
        # Animation stuff
        self.Graphics: dict[str, pygame.Surface] = animation
        self.anim_list: list[str] = list(self.Graphics.keys())
        self.anim_index: float = 0
        self.anim_speed: float = anim_speed

        # Tile init
        super().__init__(self.Graphics[self.anim_list[int(self.anim_index)]], pos, groups, blit_layer, TILESIZE)

    def animate(self, dt: float):
        self.anim_index += self.anim_speed * dt
        self.anim_index %= len(self.anim_list)

        self.image = self.Graphics[self.anim_list[int(self.anim_index)]]

    def update(self, dt: float):
        self.animate(dt)


# - Particular Glowy Tile
class PGlowy_Tile(Glowing_Tile):
    def __init__(self, add_particle: Callable[[str, list[int], Any], None], img, pos, groups = None, glow_radius = 32, glow_color = (20, 20, 20), blit_layer = 0, glow_img = pygame.Surface((TILESIZE, TILESIZE))):
        super().__init__(img, pos, groups, glow_radius, glow_color, blit_layer, glow_img)
        self.add_p: Callable[[str, list[int], Any], None] = add_particle
        self.add_particle_timer: Timer = Timer(0.05)

    def update(self, dt: float):
        if not self.add_particle_timer.active:
            self.add_p('1', [self.hitbox.centerx + (random.randint(0,4)-2), self.hitbox.centery + (random.randint(0,4)-3)], 'P2', [random.choice((-0.1,0,0.1)), -0.5], 0.1, random.randint(8,12))

            self.add_particle_timer.activate()
        self.add_particle_timer.update()



# Other

# - Player
class Player(Character_Body):
    IO: Input | None=None
    SO: REVe.utils.Sound.Sounds | None=None

    interact: bool = False

    def __init__(self, animation: dict[str, dict[str, pygame.Surface]], pos: list[int], groups: pygame.sprite.Group | None, get_neighbors: Callable[[int, list[int]], None], remove_sprite: Callable[[int, list[int]], None], screen_shake: Callable[[int], None], layer: int=0):

        # States and stuff.
        self.facing: str = random.choice(['Left', 'Right'])
        self.state: str = 'Idle'
        self.old_state: str = self.state

        self.state_repeat: dict[str, bool] = {
            'Idle': True,
            'Run': True,
            'Fall': True,
            'Jump': True,
            'Dash': False
        }

        # Graphics / Animations.
        self.Graphics: dict[str, dict[str, pygame.Surface]] = animation
        self.anim_list: list[str] = list(self.Graphics[self.state].keys())
        self.anim_speed: int = 1
        self.anim_index: int = 0

        # Call the Character body init function.
        super().__init__(self.Graphics[self.state][self.anim_list[self.anim_index]], pos, groups, layer)
        self.set_hitbox((1,0), (12,18))

        # Collisions and all that
        self.screen_shake: Callable[[int], None] = screen_shake
        self.get_neighbors: Callable[[int, list[int]], list[Any]] = get_neighbors
        self.remove_sprite: Callable[[int, list[int]], None] = remove_sprite
        self.neighbors: list[Any] = []
        
        # Movement
        self.velocity: vec2 = vec2()

        # Stats
        self.Stats: dict[str, int | float] = {
            'Health': 100,
            'Stamina': 100,
            'Speed': 164,
            'Jump_Gravity': 544,
            'Fall_Gravity': 736,
            'Remaining_Jumps': 2,
            'Jump_Force': 240
        }

        self.current_health: int = self.Stats['Health']
        self.current_stamina: int = self.Stats['Stamina']
        self.coins: int = 0

        # Stuff
        self.velocity: vec2 = vec2()
        self.gravity: float = self.Stats['Fall_Gravity']

        self.jump: bool = False
        self.jump_count: int = self.Stats['Remaining_Jumps']

        # Other
        self.on_surface: dict[str, bool] = {'floor': False, 'right': False, 'left': False}

        self.timer: dict[str, Timer] = {
            'screen_shake': Timer(0.5),
            'involnerable': Timer(1.0)
        }

    def input(self):
        # Horizontal movement
        if self.IO.map_Inputs['left'].pressed:
            self.facing = 'Left'
            self.velocity.x = -1
        elif self.IO.map_Inputs['right'].pressed:
            self.facing = 'Right'
            self.velocity.x = 1
        else:
            self.velocity.x = 0

        # Jumping
        if self.IO.map_Inputs['jump'].just_pressed:
            self.jump = True
            self.jump_count -= 1

        # Interacting
        self.interact = True if self.IO.map_Inputs['interact'].just_pressed else False

    def animate(self, dt: float):
        self.anim_list = list(self.Graphics[self.state].keys())
        self.anim_speed = len(self.anim_list) * 2
        if self.state != self.old_state:
            self.anim_index = 0

        self.anim_index += self.anim_speed * dt
        self.anim_index %= len(self.anim_list)
        current_img = self.Graphics[self.state][self.anim_list[int(self.anim_index)]].copy()

        self.image = current_img if self.facing == 'Right' else pygame.transform.flip(current_img, True, False)

    def move(self, dt: float):

        # Horizontal Movement and Collosion
        self.hitbox.x += int(self.velocity.x * self.Stats['Speed'] * dt)
        self.collision('horizontal')

        # Vertical Movement and Collision
        if not self.on_surface['floor']:
            self.velocity.y += 0.5 * self.gravity * dt
            self.hitbox.y += round(self.velocity.y * dt)
            self.velocity.y += 0.5 * self.gravity * dt

        if self.on_surface['floor']:
            self.velocity.y = 0
            self.jump_count: int = self.Stats['Remaining_Jumps']

        if self.jump:
            self.jump = False

            if self.on_surface['floor']:
                self.velocity.y = -self.Stats['Jump_Force']
                self.hitbox.y += round(self.velocity.y * dt)

            if not self.on_surface['floor'] and self.jump_count > 0:
                self.velocity.y = -self.Stats['Jump_Force']
                self.hitbox.y += round(self.velocity.y * dt)

        self.collision('vertical')

        # Move the Player Image Accordingly
        self.rect.x = self.rect.x + self.hitbox.x - self.old_rect.x
        self.rect.y = self.rect.y + self.hitbox.y - self.old_rect.y

    def check_contact(self):
        floor_rect = pygame.Rect(self.hitbox.bottomleft, (self.hitbox.width, 1))
        right_rect = pygame.Rect((self.hitbox.topright + vec2(0, self.hitbox.height/4)), (1, self.hitbox.height/2))
        left_rect = pygame.Rect((self.hitbox.topleft + vec2(-1, self.hitbox.height/4)), (1, self.hitbox.height/2))

        collide_rects: list[pygame.Rect] = [sprite.rect for sprite in self.neighbors]

        self.on_surface['floor'] = True if floor_rect.collidelist(collide_rects) >= 0 else False
        self.on_surface['right'] = True if right_rect.collidelist(collide_rects) >= 0  else False
        self.on_surface['left'] = True if left_rect.collidelist(collide_rects) >= 0 else False

    def collision(self, axis):
        for sprite in self.neighbors:
            if hasattr(sprite, 'name'):
                match sprite.name:
                    case 'G_coin':
                        self.remove_sprite(sprite.blit_layer, sprite.spawn_pos)
                        self.neighbors.remove(sprite)
                        self.coins += 2
                        self.Stats['Speed'] += 2
                        self.SO.play(random.choice(['interact', 'collect']), 0.2)

                    case 'S_coin':
                        self.remove_sprite(sprite.blit_layer, sprite.spawn_pos)
                        self.neighbors.remove(sprite)
                        self.coins += 1
                        self.Stats['Speed'] += 1
                        self.SO.play(random.choice(['interact', 'collect']), 0.2)

                    case 'flag':
                        self.neighbors.remove(sprite)

                    case 'door':
                        self.neighbors.remove(sprite)

                    case _:
                        pass

                # Check collisions
                super().collision(axis)

    def take_damage(self, damage: int):
        if not self.timer['involnerable'].active:
            self.current_health -= damage
            self.current_health = REVe.clamp(self.current_health, 0, self.Stats['Health'])
            self.timer['involnerable'].activate()
            self.timer['screen_shake'].activate()
        else:
            pass

    def get_state(self):
        if self.on_surface['floor']:
            if self.velocity.x == 0:
                self.state = 'Idle'
            else:
                self.state = 'Run'

        if not self.on_surface['floor']:
            if self.velocity.y >= 0:
                self.state = 'Fall'
            else:
                self.state = 'Jump'

    def update_timers(self):
        for timer in self.timer:
            self.timer[timer].update()

    def update(self, dt: float):
        self.old_rect = self.hitbox.copy()
        self.old_state = self.state
        self.neighbors = self.get_neighbors(self.blit_layer, self.hitbox.center)
        self.gravity = self.Stats['Fall_Gravity'] if self.velocity.y < 0 else self.Stats['Jump_Gravity']

        self.input()
        self.move(dt)
        self.check_contact()
        self.animate(dt)
        self.get_state()
        self.update_timers()

        if self.timer['screen_shake'].active:
            self.screen_shake(8)



# - Drone
class Drone(Character_Body):
    player: Player | None=None
    min_dist: int = 2*TILESIZE
    notice_radius: int = 5*TILESIZE

    def __init__(self, animation: dict[str, dict[str, pygame.Surface]], projectile_anim: dict[str, pygame.Surface], pos: list[int], groups: pygame.sprite.Group | None, layer: int=0):

        # States and stuff
        self.state: str = 'Idle'
        self.facing: str = random.choice(['Left', 'Right'])
        self.old_state: str = self.state

        self.state_repeat: dict[str, bool] = {
            'Follow': True,
            'Idle': True,
            'Damage': False
        }

        # Graphics / Animations.
        self.Graphics: dict[str, dict[str, pygame.Surface]] = animation
        self.anim_list: list[str] = list(self.Graphics[self.state].keys())
        self.anim_speed: int = 1
        self.anim_index: int = 0

        self.projectile_anim: dict[str, pygame.Surface] = projectile_anim

        # Statistics
        self.Stats: dict[str, Any] = {
            'Health': 10,
            'Speed': 128
        }

        self.current_health: int = self.Stats['Health']

        # Call the Character body init function.
        super().__init__(self.Graphics[self.state][self.anim_list[self.anim_index]], pos, groups, layer)
        self.set_hitbox((0, 0), (16,10))

        # Attacking.
        self.attack_timer: Timer = Timer(2)
        self.can_attack: bool = False

    def logic(self):
        # The Drones logic
        dist = REVe.distance(self.hitbox.center, self.player.hitbox.center)

        if REVe.clamp(dist, self.min_dist, self.notice_radius) == dist:
            self.velocity = vec2(REVe.get_velocity_vector(self.hitbox.center, self.player.hitbox.center))
            self.state = 'Follow'
            self.facing = 'Left' if self.hitbox.x < self.player.hitbox.x else 'Right'
        elif dist < self.min_dist:
            self.state = 'Idle'
            if not self.attack_timer.active:
                if self.can_attack:
                    self.attack_timer.activate()
                    self.spawn_projectile()
                else:
                    self.can_attack = True
        else:
            self.can_attack = False
            self.state = 'Idle'

    def spawn_projectile(self):
        projectile: Projectile = Projectile(self.projectile_anim, 8, self.hitbox.center, vec2(REVe.get_velocity_vector(self.hitbox.center, self.player.hitbox.center)), self.groups, self.blit_layer)
        projectile.player = self.player

    def move(self, dt: float):
        # Move the Drone
        if self.state == 'Follow':
            self.hitbox.x += int(self.Stats['Speed'] * self.velocity.x * dt)
            self.hitbox.y += int(self.Stats['Speed'] * self.velocity.y * dt)

        self.rect.x = self.rect.x + self.hitbox.x - self.old_rect.x
        self.rect.y = self.rect.y + self.hitbox.y - self.old_rect.y


    def animate(self, dt: float):
        self.anim_list = list(self.Graphics[self.state].keys())
        self.anim_speed = len(self.anim_list) * 2
        if self.state != self.old_state:
            self.anim_index = 0

        self.anim_index += self.anim_speed * dt
        self.anim_index %= len(self.anim_list)
        current_img = self.Graphics[self.state][self.anim_list[int(self.anim_index)]].copy()

        self.image = current_img if self.facing == 'Right' else pygame.transform.flip(current_img, True, False)


    def update(self, dt: float):
        self.attack_timer.update()
        self.old_rect = self.hitbox.copy()
        self.old_state = self.state

        self.logic()
        self.move(dt)
        self.animate(dt)



# - Projectile
class Projectile(Animated_Tile):
    player: Player | None=None
    velocity: vec2 = vec2()
    speed: float = 128
    damage: int = 12

    def __init__(self, animation: dict[str, pygame.Surface], anim_speed: float, pos: list[int], velocity: vec2, groups: list[pygame.sprite.Group], blit_layer: int):
        super().__init__(animation, anim_speed, [pos[0], pos[1]-12], groups, blit_layer)
        
        self.velocity = velocity

        self.live_timer: Timer = Timer(3)
        self.live_timer.activate()

    def logic(self):
        if self.hitbox.colliderect(self.player.hitbox):
            self.player.take_damage(self.damage)
            self.kill()

    def move(self, dt: float):
        self.hitbox.x += round(self.speed * self.velocity.x * dt)
        self.hitbox.y += round(self.speed * self.velocity.y * dt)

        self.rect.center = self.hitbox.center

    def update(self, dt: float):

        self.logic()
        self.move(dt)
        self.animate(dt)

        self.live_timer.update()
        if not self.live_timer.active:
            self.kill()



# - Door Class
class Door(Tile):
    player: Player | None=None
    def __init__(self, init: Callable[[], None], img: pygame.Surface, pos: list[int], groups: pygame.sprite.Group | None=None, blit_layer: int=0):
        super().__init__(img, pos, groups, blit_layer, TILESIZE)
        self.init_level: Callable[[], None] = init

    def update(self, dt: float):
        if self.hitbox.colliderect(self.player.hitbox) and self.player.interact:
            path = join('Assets', 'Maps', f"{self.properties['map']}")
            try:
                self.init_level(path)
                print()
            except:
                print(f"{path} doesn't exist ... yet?")