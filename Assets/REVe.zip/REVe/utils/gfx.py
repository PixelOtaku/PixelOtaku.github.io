import pygame, os
from pygame.math import Vector2 as vec2

"""
    A set of functionality thats going to be used to manipulate pygame.Surfaces in many different ways
"""

def clip(surf: pygame.Surface, rect: pygame.Rect | list[int, int, int, int], color_key: list[int] | None=None) -> pygame.Surface:

    """
        This function allows you to clip a section of the provided surface, just specify the (pos.x, pos.y, size.width, size.height): list[int, int, int, int] or a pygame.Rect object
    """

    if type(rect) == any((tuple, list)) and len(rect) == 4:
        clipR: pygame.Rect = pygame.Rect(*rect)
    elif type(rect) == pygame.Rect:
        clipR: pygame.Rect = rect
    else:
        print('Voetsek !!! ...')
        return
    
    surf.set_clip(clipR)
    image = surf.subsurface(surf.get_clip()).copy()
    if color_key != None:
        image.set_colorkey(color_key)
    surf.set_clip(None)
    return image


def blit(dest_surf: pygame.Surface, surf: pygame.Surface, pos: list[int], rotation: float=0, scale: float=1, center: bool=False , flags: int=0) -> None:

    """
        This function allows you to blit stuff onto a pygame surface about its center after rotating it by a certain angle.
    """

    img = surf
    img = pygame.transform.scale(surf, vec2(surf.get_size())*scale) if scale != 1 else img
    img = pygame.transform.rotate(img, rotation) if rotation != 0 else img
    pos = pos if not center else (pos[0] - img.get_width() // 2, pos[1] - img.get_height() // 2)
    dest_surf.blit(img, pos, special_flags=flags)


def palette_swap(surf: pygame.Surface, old_color: list[int], new_color: list[int]) -> pygame.Surface:

    """
        Swap a color from a pygame.Surface with another color.
    """

    new_surf: pygame.Surface = pygame.Surface(surf.get_size())
    new_surf.fill(new_color)
    surf.set_colorkey(old_color)
    new_surf.blit(surf)
    return new_surf


def import_animation(animation_path: str) -> dict[str, pygame.Surface]:
    """
        Load animation from a specified folder.
    """
    animation_dict: dict[str, pygame.Surface] = {}

    for image in os.listdir(animation_path):
        animation_dict[image.split('.')[0]] = pygame.image.load(os.path.join(animation_path, image)).convert_alpha()
        animation_dict[image.split('.')[0]].set_colorkey((0,0,0))

    return animation_dict


def import_animations(animation_path: str) -> dict[str, dict[str, pygame.Surface]]:
    """
        Load animations from all the subfolders of a specified folder.
    """
    animation_dict: dict[str, dict[str, pygame.Surface]] = {}

    for animation in os.listdir(animation_path):
        animation_dict[animation] = import_animation(os.path.join(animation_path, animation))

    return animation_dict




class Particle_Manager:
    def __init__(self):
        pass