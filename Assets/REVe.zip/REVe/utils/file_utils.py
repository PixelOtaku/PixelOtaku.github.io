import pygame, json
from typing import Any
from os.path import join
from .. import __path__

"""
    A bunch of functions that allow you to read and write to files. You can use some of these functions to import assets or save game data
"""

def read_f(path: str) -> str:
    """
        Import data from the file which is specified from path as a string
    """

    with open(path, 'r') as f:
        data = f.read()
    return data


def write_f(path: str, data: str) -> None:
    """
        Save data (probably a string) to the file you specified as a path
    """

    with open(path, 'w') as f:
        f.write(data)


def read_json(path: str) -> dict:
    """
        Import data from the file which is specified from path as a dictionary
    """

    with open(path, 'r') as f:
        data: dict = json.load(path)
    return data


def write_json(path: str, data: dict) -> None:
    """
        Save data (this was meant for dictionaries) to a file you specified as a path
    """

    with open(path, 'w') as f:
        json.dump(data, f)