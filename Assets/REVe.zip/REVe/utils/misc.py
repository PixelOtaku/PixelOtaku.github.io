import pygame, time, REVe
from os.path import join
from typing import Any, Callable

"""
    A module that contains a number useful classes for making games using REVe
"""


# Timer
class Timer:
    """
        A Timer function that has to be updated every frame making it useful for games.
        You can add a custom duration and a function you want to call when it times out.

        NB: The timer uses seconds instead of miliseconds
    """

    def __init__(self, duration: float, func: Callable[[Any], Any] | None=None, repeat: bool=False):

        self.duration: float = duration
        self.start_time: float = 0
        self.time_elapsed: float = 0
        self.repeat: bool = repeat
        self.active: bool = False

        self.func: Callable[[Any], Any] | None = func

    def activate(self):

        """
            Start/Activate the Timer.
        """

        self.start_time = time.time()
        self.active = True

    def deactivate(self):

        """
            Stop/Deactivate the Timer.
        """

        self.start_time = 0.0
        self.time_elapsed = 0.0
        self.active = False

        if self.repeat:
            self.activate()

    def update(self):

        """
            Update the timer.
        """
        self.time_elapsed = time.time() - self.start_time
        if self.time_elapsed >= self.duration:
            if self.func != None:
                self.func()
            self.deactivate()



# Custom Font
class Custom_Font:

    """
        This Class creates a custom font from a specified image and allows you to render text to a pygame.Surface using the .render function you can write stuff on the surface
    """

    def __init__(self, font_path: str, scale: int | float = 1, space: int=1, color: list[int] | None=None):

        sc = scale if scale > 0 else 1
        self.spacing = space

        self.char_order = [
            'A', 'B', 'C', 'D', 'E', 'F', 'G', 'H', 'I', 'J', 'K', 'L', 'M', 'N', 'O', 'P', 'Q', 'R', 'S', 'T', 'U', 'V', 'W', 'X', 'Y', 'Z', 'a', 'b', 'c', 'd', 'e', 'f', 'g', 'h',
            'i', 'j', 'k', 'l', 'm', 'n', 'o', 'p', 'q', 'r', 's', 't', 'u', 'v', 'w', 'x', 'y', 'z', '0', '1', '2', '3', '4', '5', '6', '7', '8', '9', '#', '!', '?', '.', ',', '[',
            ']', '(', ')', '/', '\\', '=', '+', '-', '*', '"', "'", '_', '<', '>', '|', '@', '$', '%', ':', ' ', '~'
        ]

        font_image = pygame.image.load(font_path).convert_alpha()
        if color != None:
            font_image = self.set_color(font_image, color)
        font_image.set_colorkey((23,23,23))

        curren_char_width = 0
        char_count = 0
        self.chars = dict()

        for x in range(font_image.get_width()):
            color = font_image.get_at((x, 0))
            if color[0] == 100:

                char_image = self.clip(font_image, x - curren_char_width, 0, curren_char_width, font_image.get_height())
                self.chars[self.char_order[char_count]] = pygame.transform.scale(char_image.copy(), (char_image.get_width() * sc, char_image.get_height() * sc))
                char_count += 1
                curren_char_width = 0

            else:

                curren_char_width += 1

    def clip(self, surf, x, y, x_size, y_size):
        handle_surf = surf.copy()
        clipR = pygame.Rect((x,y), (x_size,y_size))
        handle_surf.set_clip(clipR)
        image = surf.subsurface(handle_surf.get_clip())
        return image

    def set_color(self, surf, new_color: tuple | list):
        handle_surf = surf.copy()
        new_surf = pygame.Surface((handle_surf.get_size()))
        new_surf.fill(new_color)
        handle_surf.set_colorkey((255,255,255))
        new_surf.blit(handle_surf, (0,0))

        return new_surf

    def render(self, surf, text, pos):
        x_offset = 0

        for char in str(text):
            surf.blit(self.chars[char], (pos[0] + x_offset, pos[1]))
            x_offset += self.chars[char].get_width() + self.spacing



# Button
class Button:

    """
        An ultra customizable class that allows you to create buttons that have animation as well,

        supported features include:
          - resizing
          - repositioning
          - retexturing (changing color)
          - rounding
          - etc

        and all of them are optional meaning you can get very unique buttons
    """

    def __init__(self, surf: pygame.Surface, text, font_path: str, pos: tuple[int], rect: tuple[int]=(40,20), colors: tuple[tuple[int]]=((180,180,180), (200,200,200), (140,140,140)),
                  offset: tuple[int]=(0,0), text_offset: tuple[int]=(5,5), border: int=2, scale: list[int] = [1,1],font_scale: int=1, max_elev: int=6, text_color: list[int]=(255,255,255),
                  hover_text: str=''):

        # Some Stuff we need to interact with the Parent Class
        self.surf: pygame.Surface = surf
        self.pos: tuple[int] = pos
        self.scale: list[int] = scale
        self.offset: tuple[int] = offset
        self.text_offset: tuple[int] = text_offset
        self.hover_text: str = hover_text

        # The Colors
        self.Top_Color: tuple[int] = colors[0]
        self.Hover_Color: tuple[int] = colors[1]
        self.Bottom_Color: tuple[int]  = colors[2]
        self.active_top_color: tuple[int] = self.Top_Color

        # The Rectangles / Buttons
        self.Top_Rect: pygame.Rect = pygame.Rect((self.pos, rect))
        self.Bottom_Rect: pygame.Rect = pygame.Rect((self.pos, rect))
        self.max_elev : int = max_elev
        self.elevation  : int = max_elev
        self.border_radius: int = border 

        # Other Things
        self.cFont: Custom_Font = Custom_Font(font_path=font_path, scale=font_scale, color=text_color)
        self.text: str = str(text)
        self.font_loc: list[int] = [self.pos[0] + self.text_offset[0], self.pos[1] + self.text_offset[1]]

        self.active: bool = False
        self.hovering: bool = False
        self.pressed: bool = False

        self.animate_timer: Timer = Timer(0.15)

    def mpos(self):
        pos = pygame.mouse.get_pos()

        x = round((pos[0] - self.offset[0]) * self.scale[0])
        y = round((pos[1] - self.offset[1]) * self.scale[1])

        return (x,y)

    def input(self):
        mouse = self.mpos()

        if self.Top_Rect.collidepoint(mouse):
            self.active_top_color = self.Hover_Color
            self.hovering = True

            if pygame.mouse.get_pressed()[0] == True:
                self.pressed = True
                self.animate_timer.activate()
            else:
                if self.pressed == True:
                    self.active = True
                    self.pressed = False
                else:
                    self.active = False
        else:
            self.active_top_color = self.Top_Color
            self.hovering = False
            self.active = False

        self.elevation = self.max_elev if not self.animate_timer.active else 0

    def draw(self):
        # Bottom Rect
        pygame.draw.rect(self.surf, self.Bottom_Color, self.Bottom_Rect, border_radius = self.border_radius)

        # Top Rect
        self.Top_Rect[1] = self.pos[1] - self.elevation
        pygame.draw.rect(self.surf, self.active_top_color, self.Top_Rect, border_radius = self.border_radius)

        # Text
        self.font_loc = [self.Top_Rect[0] + self.text_offset[0], self.Top_Rect[1] + self.text_offset[1]]
        self.cFont.render(self.surf, self.text, self.font_loc)

    def update(self, scale: list[int]=[1, 1]):
        self.scale = scale
        self.input()
        self.draw()

        self.animate_timer.update()