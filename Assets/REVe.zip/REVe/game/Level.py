import pygame, random
from typing import Callable
from pygame.math import Vector2 as vec2
from .Registry import Singleton
from ..utils.gfx import blit
from ..utils.math import get_velocity_vector, clamp, distance


# The Layout Manager
class Layout(Singleton):
    """
        This Class is meant to be the thing that handles the spawning and KILLING of Sprites in the game.
        Note [!] it has access to the Register for input purposes.
    """
    def __init__(self, id: str):
        super().__init__(id)
        self.id = id

    def update(self):
        """
            Update the Layout manager.
        """
        pass





# The REVe Camera
class Camera(pygame.sprite.Group):
    """
        A Simple Camera with a bunch of configurations like a follow camera, center camera, the box camera, keyboard controlled and some more.

        The Camera's blit / custom draw function has support for Platformer Blitting, Top-Down and probably more.

        The Camera Has a Few Effects as well which include Screen Shake
    """

    def __init__(self, Surface: pygame.Surface, tile_size: int=16):
        super().__init__()

        # Boilerplate shit
        self.Surface: pygame.Surface = Surface
        self.Surf_size: vec2 = vec2(self.Surface.get_width(), self.Surface.get_height())
        self.origin: vec2 = vec2()
        self.tile_size: int = tile_size

        # Follow Cam properties

        # Keyboard control Cam properties
        self.keyboard_control_speed = 5


    def center_camera(self, target: pygame.Rect | None=None) -> None:
        """
            Centers the target on the screen
        """
        if target != None:
            self.origin.x = target.centerx - (self.Surf_size.x//2)
            self.origin.y = target.centery - (self.Surf_size.y//2)
        else:
            self.origin.x, self.origin.y = 0, 0


    def follower_camera(self, target: pygame.Rect, speed: int, dt: float, buffer: list[list[int]]=[[-8, 8], [-4, 4]]):
        """
            This camera replicates the camera innit that it literally follows the player at a certain speed
        """
        x_diff: int = self.origin.x - target.centerx + (self.Surf_size.x//2)
        y_diff: int = self.origin.y - target.centery + (self.Surf_size.y//2)
        dist: int = distance([self.origin.x, self.origin.y], [target.centerx - (self.Surf_size.x//2), target.centery - (self.Surf_size.y//2)])

        if any((clamp(x_diff, buffer[0][0], buffer[0][1]) != x_diff, clamp(y_diff, buffer[1][0], buffer[1][1]) != y_diff)):
            cam_dir: list[int] = get_velocity_vector([self.origin.x, self.origin.y], [target.centerx - (self.Surf_size.x//2), target.centery - (self.Surf_size.y//2)])
        else:
            cam_dir: list[int] = [0, 0]

        self.origin.x = self.origin.x + round(cam_dir[0] * speed * dt) if dist > 24 else self.origin.x + (round(cam_dir[0] * dist * speed * dt / self.Surf_size.x//1))
        self.origin.y = self.origin.y + round(cam_dir[1] * speed * dt) if dist > 24 else self.origin.y + (round(cam_dir[1] * dist * speed * dt / self.Surf_size.y//1))

    
    def keyboard_control(self, direction: list[int]) -> None:
        """
            This Allows you to control the Camera using the Keyboard
        """
        self.origin += vec2(direction[0] * self.keyboard_control_speed, direction[1] * self.keyboard_control_speed)


    def Screen_shake(self, strength: int):
        """
            Gives the Screen a lil shake!!!
        """
        self.origin.x += random.randint(0, strength) - strength // 2
        self.origin.y += random.randint(0, strength) - strength // 2


    def Draw_Platformer(self, draw_order: Callable[[object], None]=lambda x: x.blit_layer):
        """
            Draws all the Sprites in the sprite list relative to the origion.

            Note [!] to save on performance, it only draws sprites within the window (that you can see).
        """
        for sprite in sorted(self.sprites(), key = draw_order):
            tl = vec2(sprite.rect.topleft) - self.origin
            if max(-self.tile_size, min(tl.x, self.Surf_size.x)) == tl.x and max(-self.tile_size, min(tl.y, self.Surf_size.y)) == tl.y:
                blit(self.Surface, sprite.image, tl)
        

    def Update_visible(self, *args):
        """
            Calls the update method for every sprite that is visible to the camera.
            
            Note [!] they have to have the same update parameters. If it doesn't have an update method it won't be called
        """

        for sprite in sorted(self.sprites(), key = lambda x: x.blit_layer):
            tl = vec2(sprite.rect.topleft) - self.origin
            center = vec2(sprite.rect.center) - self.origin
            if max(-self.tile_size, min(tl.x, self.Surf_size.x)) == tl.x and max(-self.tile_size, min(tl.y, self.Surf_size.y)) == tl.y:
                if hasattr(sprite, 'update'):
                    sprite.update(*args)





# The Heads Up Display
class HUD(Singleton):
    """
        The Heads Up Display (HUD). This Is a rather simple class, It isn't really necessary but since pixel art has to be scaled while some UI elements Shouldn't it might come in Handy as it is has Access to the Registry
    """
    def __init__(self):
        super().__init__('HUD')
        self.Surface: pygame.Surface = self.Registry['Window'].screen

    def update(self):
        """
            update the HUD.
        """