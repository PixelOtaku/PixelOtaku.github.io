from typing import Any

"""
    The calsses responsible for enabling the REV engine to use the Container / Resitry programming pattern.
"""

class Singleton:
    """
        For An Element to be Recognized as part of the Games Registry it has to Inherit from the Singleton Class
    """

    def __init__(self, custom_id: str | None=None):
        self.Registry: Registry = registry
        self.name = __class__.__name__ if not custom_id else custom_id
        self.Registry.register(self)

class Registry:
    """
        This is the bit that allows REVe to use the Container / Resistry programming Pattern allowing it to access a bunch of properties from anywhere without depending on a heirachy.
    """

    singles: dict[str, Singleton] = {}
    collections: dict[str, Any] = {}

    def register(self, single: Singleton) -> None:
        """
            Adds an Element to the Games Registry.
        """
        self.singles[single.name] = single


    def Add_group(self, id: str, item: Any) -> None:
        """
            Craetes a new collection in the Registry.
        """
        if id not in self.collections:
            self.collections[id] = item
    

    def Get_collection(self, id: str) -> Any | None:
        """
            Returns a collection if it's found in the Registry.
        """
        if id in self.collections:
            return self.collections[id]
        else:
            return None


    def Add_item(self, collection_id: str, item_id: str, item: Any) -> None:
        """
            Adds a new item to a collection found in the Registry
        """
        if collection_id in self.collections:
            self.collections[collection_id][item_id] = item
        else:
            self.collections[collection_id] = {}
            self.collections[collection_id][item_id] = item


    def Get_item(self, collection_id: str, item_id: str) -> Any | None:
        """
            Gets an item from specified collection found in the Registry.
        """
        if collection_id in self.collections:
            if item_id in self.collections[collection_id]:
                return self.collections[collection_id][item_id]
            else:
                return None
        else:
            return None

 
    def __getitem__(self, name: str) -> Singleton | None:
        """
            Gets an Element from the games Registry.
        """
        if name in self.singles:
            return self.singles[name]
        else:
            return None


    def remove(self, name) -> None:
        """
            Removes an Element from the Games Registry.
        """

        if name in self.singles:
            del self.singles[name]

registry: Registry = Registry()