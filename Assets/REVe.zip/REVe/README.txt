Alrigth, so REV engine (not really an egine, it's a framework) / REVe pronounced like the French word for dream is something i built so that i don't have to keep rebuilding some systems in my game.
So I'm PixelOtaku, I'm a game development hobbyist who just turned 16 and I have a YouTube channel (@PixelOtaku1) which you can check out if you want to and show some support (or even some constructive critisism if possible) to help me grow

Like I said, I added stuff that I knew I would need but didn't want to have to build from scratch because it's a hassle. I included the following:
    - Quite a bit of pygame function abstraction
    - I made a few API's like my MGL (modernGL) API for GPU based rendering
    - I made a simple but powerful map Editor that allows me to create and edit REVe maps
    - I also built the Framework with the use of the Container/Registry programming pattern because I wanted something similar to Godot's node tree
    - As well as a bunch more stuff

Note [!] This framework is not fully independent of pygame, It was made to provide me with a bunch of functionality to speed up my pygame workflow.