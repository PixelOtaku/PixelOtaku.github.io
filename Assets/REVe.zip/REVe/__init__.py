"""
    The REV engine, REVe (pronouced like the french word for dream) is a 2D game making framework made by PixelOtaku.
    It is built atop of (But is not full independent on) pygame-ce, mordengl and a few other modules which enable it to:

    - Create Windows
    - Blit Stuff onto the Window
    - Handle user input
    - Import Assets like images and sounds
    - Create moderngl contexts
    - Run stuff like shaders on the GPU
    - and soo much more ...

    It also comes with it's own built-in map editor

    That's the plan at least
"""

# Metadata
__name__ = 'REVe'
__author__ = 'PixelOtaku'
__version__ = '1.0.0'

print(f"You're Rocking REV engine version {__version__}")

# Imports
from .misc.error import Err
from .game.REV_game import REV_game
from .game.Window import Window
from .game.Level import Layout, Camera, HUD
from .Editor.tiling import Tilemap, Tileset
from .utils.gfx import blit
from .utils.math import *

# Functions

def quit() -> None:
    """ Stop and exit """
    import pygame, sys

    pygame.quit()
    sys.exit()