"""
    Various types of entities that can be used fresh out of the box or with a bit of customization
    which include Tiles, NPCs, Enemies, the varois Player controllers for various types of games, and a few more
"""