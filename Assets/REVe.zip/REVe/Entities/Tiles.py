import pygame
from pygame.math import Vector2 as vec2

class Tile(pygame.sprite.Sprite):
    """
        One of REVe's simplest objects, it has an image, a rectangle as well as a hitbox. You also have the option to add certain properties
    """
    def __init__(self, img: pygame.Surface, pos: list[int], groups: list[pygame.sprite.Group]=[], blit_layer: int=0, properties: dict[str, str]={}, tilesize: int=16):
        super().__init__(groups)

        # Boilerplate
        self.image: pygame.Surface = img
        self.rect: pygame.Rect = self.image.get_rect(topleft = (pos[0], pos[1] - (self.image.get_height() - tilesize)))
        self.name: str = self.__class__.__name__
        self.groups: list[pygame.sprite.Group] = groups
        self.spawn_pos: list[int] = pos
        self.properties: dict[str, str] = properties

        # This bit is for if the Tile Glows
        self.glow_img: pygame.Surface = None
        self.glow_pos: list[int] | pygame.math.Vector2 = self.rect.center

        # Collision stuff
        self.hitbox: pygame.Rect = self.rect.copy()
        self.old_rect: pygame.Rect = self.hitbox.copy()
        self.rect_offset: vec2 = vec2()
        
        # Blitting layer
        self.blit_layer: int = blit_layer

    def set_hitbox(self, offset: list[int], size: list[int]) -> None:
      """
         Quickly fix the hitbox.
      """
      self.rect_offset = vec2(offset[0], offset[1])
      pos = (self.rect.x + self.rect_offset.x, self.rect.y + self.rect_offset.y)
      self.hitbox = pygame.Rect(pos , size)
      self.old_rect = self.hitbox.copy()