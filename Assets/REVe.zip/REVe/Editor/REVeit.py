import pygame, sys
from os.path import join
from typing import Any
from pygame.math import Vector2 as vec2
from ..utils.misc import Custom_Font, Button, Timer
from .tiling import Tileset
from ..utils.file_utils import read_f, write_f
from ..utils.math import clamp





# ======================================== Outside ========================================

pygame.font.init()
debug_font: pygame.font.Font = pygame.font.Font(None, 16)


def debug(surf: pygame.Surface, text: str, pos: list[int], color: tuple[int]=(170,170,170), left: bool=False) -> None:
    debug_surf = debug_font.render(str(text), True, color)
    debug_back = pygame.Surface(debug_surf.get_size() + vec2(16, 8))
    debug_back.fill((25,25,25))
    debug_back.blit(debug_surf, (8,4))
    draw_pos = pos if not left else (pos[0] - debug_back.width, pos[1])
    debug_rect = debug_back.get_rect(topleft=draw_pos)
    surf.blit(debug_back, debug_rect)





# ======================================== Other stuff ========================================

helping_text: list[str] = [
                f"{'_'*46} HELP SECTION {'_'*46}", '', '',

                f'{' '*5}Left click to add tile to tiledata.', '', '',

                f'{' '*5}Right click to remove tile from tiledata.', '', '',

                f'{' '*5}Hold the middle mouse button (or ALT) and move the cursor to move the Camera.', '', '',

                f'{' '*5}CTRL + S to save the map (the .revemp file)', '', '',

                f'{' '*5}S to select a tile (Move cursor to bottomleft of image)', '', '',

                f'{' '*5}R to reset the origion\'s position.', '', '',

                f"{'_'*104}", '',

                f'{' '*2}NOTE [!] REVeit stores it\'s tile data in a dictionary of type dict [ layer, dict [ pos , data ] ] :', '',

                f'{' '*5}- layer is of type int ( e.g. 1, 3, 19, 47, ...)', '',

                f'{' '*5}- pos is a string containing the grid position of the tile ( e.g. "[ 0, 3 ]", "[ 2, 6 ]")', '',

                f'{' '*5}- data is a dictionary containing the int LAYER, str IMG (name), list POS, str TILESET and dict PROPERTIES', '',

                f'{' '*7}- PROPERTIES is a dictionary containing any additional properties the tile has.', '',
                f'{' '*7}- These can be added during map editing.', '', '',

                f'{' '*2} in Python you can extract data like so:', '',

                f'{' '*5}- map = eval ( REVe.utils.file_utils.readf ( "map_name.revemp"))'

            ]

Info_text: list[str] = [
    f"{'_'*48} INFO SECTION {'_'*48}", '', '',

    f'- REVeit ( REVe edit ) is a simple map editor made using Python as a part of REVe', '', '',

    f'- REVeit was made using REV engine (which was built atop of pygame-ce) as well as pygame-ce', '', '',

    f'- Just like REVe, I (PixelOtaku) built everything myself.', '', '',

    f'- I decided not to make it an executable just in case I wanted to use it in a game', '', '',

    f'- This section was added just in case pygame-ce tries to sue me or something for not giving them credit.', '', '',

    f'- Note [!] Just like REVe, REVeit was made to satisfy my own use cases but if you would like to use it then go ahead', '', '',

    f'- I might provide some documentation in future. For now though, the help section is enough.', '', '',

    f'- Check out my channel ( www.youtube.com/@PixelOtaku1 ) or my website ( PixelOtaku.github.io )'
]





# ======================================== Main stuff ========================================

class Section:

    """
        An Object containing it's own Surface as well as a Rect
    """

    def __init__(self, size: vec2, pos: vec2, color: list[int]=[255,255,255], visible: bool = True):
        self.color: list[int] = color
        self.size: vec2 = size
        self.surf: pygame.Surface = pygame.Surface((size))
        self.rect: pygame.Rect = pygame.Rect(pos, size)
        self.pos: vec2 = pos

        self.visible: bool = visible

        self.clear()

    def clear(self):

        """
            Clear the Surface of the Section (fill it with it's origional color).
        """

        self.surf.fill((self.color))



class main:

    """
        REV engine's very own map editor with a plathera of features
    """

    # Some pre-init stuff

    # ----- Constants -----
    SCREEN_SIZE: vec2 = vec2(1280, 720)
    DISPLAY_SIZE: vec2 = vec2(1280, 720)
    RENDER_SCALE: int = 2

    # ------- Filing ------

    filepath: str = 'untitled.revemp'

    # ------- Display -----
    pygame.display.set_caption(f"REVeit : {filepath}")
    screen: pygame.Surface = pygame.display.set_mode(SCREEN_SIZE)
    display: pygame.Surface = pygame.Surface(DISPLAY_SIZE)
    clock: pygame.time.Clock = pygame.time.Clock()

    # ----- Tiles ---------

    tilesets: dict[str, Tileset] = {}
    tile_configs: dict = {}
    tile_data: dict[str, dict[int, dict[str, Any]]] = {}
    NEIGHBORS: dict[str, str] = {
        (-1,0): 'LEFT',
        (-1,1): 'BOTTOM_LEFT',
        (0, 1): 'BOTTOM',
        (1, 1): 'BOTTOM_RIGHT',
        (1, 0): 'RIGHT',
        (1,-1): 'TOP_RIGHT',
        (0,-1): 'TOP',
        (-1,1): 'TOP_LEFT',
    }
    tile_count: int = 0

    # Text and Stuff

    accepting_text: bool = False
    current_text: str = ''

    # Warnings

    warnings: list[str] = []
    warning_timer: Timer = Timer(3)

    # ----- Other ---------

    func2: bool = False

    adding_tile: bool = False
    removing_tile: bool = False
    current_layer: int = 0
    prompting: bool = False

    dt: float = 0
    FPS: float = 0


    def __init__(self, default_path: str, tilesets: dict[str, dict[str, pygame.Surface]], tile_configs: dict[str, dict]={}, tile_size: int=16, render_scale: int=2, auto_tile: list[str] | None=None):

        # some stuff
        self.TILESIZE: int = tile_size*2
        self.RENDER_SCALE: int = render_scale

        # Tile data stuff
        self.tilesets: dict[str, dict[str, pygame.Surface]] = tilesets
        self.tile_configs: dict[str, dict] = tile_configs
        self.auto_tile_tiles: list[str] | None = auto_tile

        self.tileset_index: int = 0
        self.tile_index: int = 0

        self.tileset_list: list[str] = list(self.tilesets.keys())
        self.current_tileset: str = self.tileset_list[self.tileset_index]

        self.tile_list: list = list(self.tilesets[self.current_tileset].values())
        self.current_tile: pygame.Surface = self.tile_list[self.tile_index]

        self.selected_tile: dict[str, Any] | None = None
        self.hovering: Button | None = None

        # ----- Fonts ---------
        self.font_path: str = join(default_path, 'blox.png')

        self.CFont_1 = Custom_Font(self.font_path, scale=1, color=(255,60,60)) # Small red font
        self.CFont_2 = Custom_Font(self.font_path, scale=1, color=(0,0,0))     # small black font
        self.CFont_3 = Custom_Font(self.font_path, scale=2, color=(0,0,0))     # medium black font
        self.CFont_4 = Custom_Font(self.font_path, scale=2, color=(128,0,0))   # medium dark red font
        self.CFont_5 = Custom_Font(self.font_path, scale=2, color=(170,170,170), space=1)     # medium black font

        # ----- Graphics -----
        self.mouse_imgs: dict[str, pygame.Surface] = {
            'mouse_left': pygame.image.load(join(default_path, 'mouse_l.png')).convert_alpha(),
            'mouse_right': pygame.image.load(join(default_path, 'mouse_r.png')).convert_alpha(),
            'mouse_mid': pygame.image.load(join(default_path, 'mouse_m.png')).convert_alpha()}
        [img.set_colorkey((0,0,0)) for img in self.mouse_imgs.values()]

        self.YT_icon: pygame.Surface = pygame.image.load(join(default_path, 'YT_icon.png')).convert_alpha()


    def update_display(self):

        # Update useful information
        self.dt = self.clock.tick(60) / 1000
        self.dt = clamp(self.dt, (1/60), (2/60))
        self.FPS = 1/self.dt if self.dt != 0 else 0

        # Update the pygame.display
        self.screen.blit(pygame.transform.scale(self.display, self.screen.get_size()))
        pygame.display.update()


    def run_Editor(self):

        # Misc
        self.origion: vec2 = vec2()                                 # The point everything will be drawn relatie to
        self.r_offset: vec2 = vec2(160,100)                          # the differenct between the windows topleft and the viewports topleft
        self.moving_origion: bool = False                           # tells us whether or not the origion is being moved

        self.mpos: vec2 = vec2(0,0)                                 # the mouse position relative to the origion (this is the one that's going to be used for adding tiles)
        self.r_mpos = vec2(pygame.mouse.get_pos()) - self.r_offset  # The mouse position relative to the viewports topleft
        self.or_mpos = self.r_mpos                                  # The r_mpos from the previous frame.
        self.diff: vec2 = self.r_mpos - self.or_mpos                # The differance between the r_mpos and or_mpos
        self.grid_pos: vec2 = self.mpos // self.TILESIZE            # The grid position relative to the origion
        self.r_grid_pos: vec2 = self.mpos // self.TILESIZE

        # Sections
        self.Sections: dict[str, Section] = {
            'Tools': Section(
                color=(200,200,200),
                size=vec2(1280,60),
                pos=vec2(0,0)
            ),

            'Tiles': Section(
                color=(96,44,104),
                size=vec2(160,1220),
                pos=vec2(0,60)
            ),

            'Layering': Section(
                color=(75,75,75),
                size=vec2(960,40),
                pos=vec2(160,60)
            ),

            'Render': Section(
                color=(25,25,25),
                size=vec2(960, 540),
                pos=self.r_offset
            ),

            'Properties': Section(
                color=(96,44,104),
                size=vec2(160, 1220),
                pos=vec2(1120, 60)
            ),

            'Load_Map_Prompt': Section(
                color=(140,140,140),
                size=vec2(480,180),
                pos=vec2(400,200),
                visible=False
            ),

            'New_Map_Prompt': Section(
                color=(140,140,140),
                size=vec2(480,180),
                pos=vec2(400,200),
                visible=False
            ),

            'Help': Section(
                color=(100,100,100),
                size=vec2(1000,700),
                pos=vec2(140,10),
                visible=False
            ),

            'Info': Section(
                color=(100,100,100),
                size=vec2(1000,700),
                pos=vec2(140,10),
                visible=False
            ),

            'Property_Edit': Section(
                color=(140,140,140),
                size=vec2(480,180),
                pos=vec2(400,200),
                visible=False
            )
        }

        # Buttons
        self.Buttons: dict[str, Button] = {
            'Reset_origion': Button(
                surf=self.Sections['Tools'].surf,
                text='Reset',
                font_path=self.font_path,
                rect=(30,20),
                pos=(110,20),
                border=5,
                text_color=(50,45,40),
                max_elev=4,
                hover_text="Reset the origion's position - Shortcut: r"
            ),

            'Save': Button(
                surf=self.Sections['Tools'].surf,
                text='Save',
                font_path=self.font_path,
                rect=(30,20),
                pos=(70,20),
                border=5,
                text_color=(50,45,40),
                max_elev=4,
                hover_text="Save the current map as a .revemp file - Shortcut: CTRL + s"
            ),

            'New': Button(
                surf=self.Sections['Tools'].surf,
                text='New',
                font_path=self.font_path,
                rect=(24,20),
                pos=(10,20),
                border=5,
                text_color=(50,45,40),
                max_elev=4,
                hover_text="Create a new map that can be saved as a .revemp file."
            ),

            'Exit_New': Button(
                surf=self.Sections['New_Map_Prompt'].surf,
                text='Cancel',
                font_path=self.font_path,
                rect=(50,24),
                pos=(40,130),
                border=5,
                text_offset=(10,5),
                text_color=(50,45,40),
                colors=((180,140,140), (220,180,180), (160,100,100)),
                offset=(400,200),
                max_elev=4
            ),

            'Accept_New': Button(
                surf=self.Sections['New_Map_Prompt'].surf,
                text=' Create ',
                font_path=self.font_path,
                rect=(50,24),
                pos=(390,130),
                border=5,
                text_offset=(5,5),
                text_color=(50,45,40),
                offset=(400,200),
                max_elev=4
            ),

            'Load': Button(
                surf=self.Sections['Tools'].surf,
                text='Load',
                font_path=self.font_path,
                rect=(24,20),
                pos=(40,20),
                border=5,
                text_offset=(2,5),
                text_color=(50,45,40),
                max_elev=4,
                hover_text="Load a map from a .revemp file into the REVeit editor. "
            ),

            'Exit_Load_Map_Prompt': Button(
                surf=self.Sections['Load_Map_Prompt'].surf,
                text='Cancel',
                font_path=self.font_path,
                rect=(50,24),
                pos=(20,130),
                border=5,
                text_offset=(10,5),
                text_color=(50,45,40),
                colors=((180,140,140), (220,180,180), (160,100,100)),
                offset=(400,200),
                max_elev=4
            ),

            'Accept_Load_Map_Prompt': Button(
                surf=self.Sections['Load_Map_Prompt'].surf,
                text='Load map',
                font_path=self.font_path,
                rect=(50,24),
                pos=(330,130),
                border=5,
                text_offset=(5,5),
                text_color=(50,45,40),
                offset=(400,200),
                max_elev=4
            ),

            'Enter_Property_Edit': Button(
                surf=self.Sections['Properties'].surf,
                text='Add property',
                font_path=self.font_path,
                rect=(64,20),
                pos=(48,180),
                border=5,
                text_color=(50,45,40),
                max_elev=4,
                offset=(1120, 60),
                hover_text="Edit currently selected tile's properties which can be used in game."
            ),

            'Apply_Property': Button(
                surf=self.Sections['Property_Edit'].surf,
                text='Add property',
                font_path=self.font_path,
                rect=(64,24),
                pos=(380,130),
                border=5,
                text_offset=(5,5),
                text_color=(50,45,40),
                offset=(400,200),
                max_elev=4
            ),

            'Exit_Property_Edit': Button(
                surf=self.Sections['Property_Edit'].surf,
                text='Cancel',
                font_path=self.font_path,
                rect=(50,24),
                pos=(40,130),
                border=5,
                text_offset=(10,5),
                text_color=(50,45,40),
                colors=((180,140,140), (220,180,180), (160,100,100)),
                offset=(400,200),
                max_elev=4
            ),

            'Layer0': Button(
                surf=self.Sections['Layering'].surf,
                text='Layer0',
                font_path=self.font_path,
                rect=(36,20),
                pos=(10,10),
                border=5,
                text_color=(50,45,40),
                offset=(160,60),
                max_elev=4,
                hover_text='Switch to Layer 0 - Shortcut: 0'
            ),

            'Layer1': Button(
                surf=self.Sections['Layering'].surf,
                text='Layer1',
                font_path=self.font_path,
                rect=(36,20),
                pos=(60,10),
                border=5,
                text_color=(50,45,40),
                offset=(160,60),
                max_elev=4,
                hover_text='Switch to Layer 1 - Shortcut: 1'
            ),

            'Layer2': Button(
                surf=self.Sections['Layering'].surf,
                text='Layer2',
                font_path=self.font_path,
                rect=(36,20),
                pos=(110,10),
                border=5,
                text_color=(50,45,40),
                offset=(160,60),
                max_elev=4,
                hover_text='Switch to Layer 2 - Shortcut: 2'
            ),

            'Layer3': Button(
                surf=self.Sections['Layering'].surf,
                text='Layer3',
                font_path=self.font_path,
                rect=(36,20),
                pos=(160,10),
                border=5,
                text_color=(50,45,40),
                offset=(160,60),
                max_elev=4,
                hover_text='Switch to Layer 3 - Shortcut: 3'
            ),

            'Layer4': Button(
                surf=self.Sections['Layering'].surf,
                text='Layer4',
                font_path=self.font_path,
                rect=(36,20),
                pos=(210,10),
                border=5,
                text_color=(50,45,40),
                offset=(160,60),
                max_elev=4,
                hover_text='Switch to Layer 4 - Shortcut: 4'
            ),

            'Help': Button(
                surf=self.Sections['Tools'].surf,
                text='?',
                font_path=self.font_path,
                rect=(24,20),
                pos=(1250,15),
                border=5,
                text_color=(50,45,40),
                text_offset=(7,3),
                max_elev=4,
                hover_text='Need HELP!? press ... HELP.'
            ),

            'Help_exit': Button(
                surf=self.Sections['Help'].surf,
                text='x',
                font_path=self.font_path,
                rect=(20,18),
                pos=(970,10),
                border=5,
                text_color=(50,45,40),
                text_offset=(7,3),
                offset=(140,10),
                max_elev=4
            ),

            'Info': Button(
                surf=self.Sections['Tools'].surf,
                text='i',
                font_path=self.font_path,
                rect=(24,20),
                pos=(1220,15),
                border=5,
                text_color=(50,45,40),
                text_offset=(7,3),
                max_elev=4,
                hover_text='What do you need to know about REVeit?'
            ),

            'Info_exit': Button(
                surf=self.Sections['Info'].surf,
                text='x',
                font_path=self.font_path,
                rect=(20,18),
                pos=(970,10),
                border=5,
                text_color=(50,45,40),
                text_offset=(7,3),
                offset=(140,10),
                max_elev=4
            ),
        }


        # Functions and stuff

        def Clear():

            """
                Clear the display.
            """

            self.display.fill((50,50,50))
            for section in self.Sections.keys():
                self.Sections[section].clear()

        def Draw_Sections():

            """
                Draw all the Sections in the editor.
            """

            for section in self.Sections.keys():
                if self.Sections[section].visible:
                    self.display.blit(self.Sections[section].surf, self.Sections[section].rect)

        def Button_update():

            """
                Update all the buttons in the editor.
            """

            self.hovering = None
            for button in self.Buttons.keys():
                b = self.Buttons[button]
                b.update()

                if b.hovering and b.hover_text != '' and not self.prompting:
                    self.hovering = b

            # Reset the origions location
            if self.Buttons['Reset_origion'].active:
                self.origion = vec2()

            # Save map
            if self.Buttons['Save'].active and not self.prompting:
                Save(self.filepath, self.tile_data)

            # The Layer select buttons 
            if self.Buttons['Layer0'].active:
                self.current_layer = 0

            if self.Buttons['Layer1'].active:
                self.current_layer = 1

            if self.Buttons['Layer2'].active:
                self.current_layer = 2

            if self.Buttons['Layer3'].active:
                self.current_layer = 3

            if self.Buttons['Layer4'].active:
                self.current_layer = 4

            # The Help section
            if self.Buttons['Help'].active:
                self.prompting = True
                self.Sections['Help'].visible = True

            if self.Buttons['Help_exit'].active and self.Sections['Help'].visible:
                self.prompting = False
                self.Sections['Help'].visible = False

            # The Info section
            if self.Buttons['Info'].active:
                self.prompting = True
                self.Sections['Info'].visible = True

            if self.Buttons['Info_exit'].active and self.Sections['Info'].visible:
                self.prompting = False
                self.Sections['Info'].visible = False

            # New Map
            if self.Buttons['New'].active:
                self.Sections['New_Map_Prompt'].visible = True
                self.prompting = True
                self.accepting_text = True

            if self.Buttons['Exit_New'].active and self.Sections['New_Map_Prompt'].visible:
                self.prompting = False
                self.Sections['New_Map_Prompt'].visible = False
                self.current_text = ''

            if self.Buttons['Accept_New'].active and self.Sections['New_Map_Prompt'].visible:
                pygame.display.set_caption(f"REVeit : {self.current_text}.revemp")
                self.filepath = f'{self.current_text}.revemp'
                self.current_text = ''
                self.prompting = False
                self.Sections['New_Map_Prompt'].visible = False
                self.tile_data = {}

                self.current_text = ''

            # Load Map
            if self.Buttons['Load'].active:
                self.prompting = True
                self.accepting_text = True
                self.Sections['Load_Map_Prompt'].visible = True

            if self.Buttons['Exit_Load_Map_Prompt'].active and self.Sections['Load_Map_Prompt'].visible:
                self.prompting = False
                self.accepting_text = False
                self.Sections['Load_Map_Prompt'].visible = False
                self.current_text = ''

            if self.Buttons['Accept_Load_Map_Prompt'].active and self.Sections['Load_Map_Prompt'].visible:
                path = f"{self.current_text}.revemp"
                flag = Load(path)
                if flag == 1:
                    pygame.display.set_caption(f"REVeit : {path}")
                    self.prompting = False
                    self.accepting_text = False
                    self.Sections['Load_Map_Prompt'].visible = False
                    self.current_text = ''

            # Edit properties
            if self.Buttons['Enter_Property_Edit'].active:
                if self.selected_tile != None:
                    self.prompting = True
                    self.accepting_text = True
                    self.Sections['Property_Edit'].visible = True
                else:
                    self.warning_timer.activate()
                    self.warnings.append("You can't edit properties of Nothing ...")

            if self.Buttons['Exit_Property_Edit'].active and self.Sections['Property_Edit'].visible:
                self.prompting = False
                self.accepting_text = False
                self.Sections['Property_Edit'].visible = False
                self.current_text = ''

            if self.Buttons['Apply_Property'].active and self.Sections['Property_Edit'].visible:
                try:
                    key, val = self.current_text.split('=')
                    self.selected_tile['Properties'][key] = val
                    self.warning_timer.activate()
                    self.warnings.append("Applied Property")

                    self.prompting = False
                    self.accepting_text = False
                    self.Sections['Property_Edit'].visible = False
                    self.current_text = ''
                except:
                    self.warning_timer.activate()
                    self.warnings.append("Invalid property assignment")

        def Draw_text():
            self.CFont_1.render(self.Sections['Render'].surf, f"relative mouse pos: {self.mpos}", (10,5))
            self.CFont_1.render(self.Sections['Render'].surf, f"relative grid pos: {self.grid_pos}", (10, 15))

            self.CFont_3.render(self.Sections['Tiles'].surf, f"Tileset: {self.current_tileset}", (16,180))
            self.CFont_3.render(self.Sections['Tiles'].surf, f"Tile: {list(self.tilesets[self.current_tileset].keys())[self.tile_index]}", (16, 210))

            self.CFont_3.render(self.Sections['Layering'].surf, f"current layer: {self.current_layer}", (700,10))

            if self.selected_tile != None:
                for line, property in enumerate(self.selected_tile['Properties']):
                    self.CFont_5.render(self.Sections['Properties'].surf, f"{property} = {self.selected_tile['Properties'][property]}", (16, 220 + (24 * line)))

            # The Load Map Prompt text
            if self.Sections['Load_Map_Prompt'].visible:
                self.CFont_2.render(self.Sections['Load_Map_Prompt'].surf, 'Please Type the name of the map you wanna load.', (10,10))
                self.CFont_3.render(self.Sections['Load_Map_Prompt'].surf, f'Currently Typed :  {self.current_text} .revemp', (10,30))

            # The New Map Prompt text
            if self.Sections['New_Map_Prompt'].visible:
                self.CFont_2.render(self.Sections['New_Map_Prompt'].surf, 'Please Enter the name you want to give to your map', (10,10))
                self.CFont_3.render(self.Sections['New_Map_Prompt'].surf, f'Currently Typed :  {self.current_text} .revemp', (10,30))

            # The Add Property Prompt
            if self.Sections['Property_Edit'].visible:
                self.CFont_2.render(self.Sections['Property_Edit'].surf, 'Set property e.g. : name="Player" (NO SPACES)', (10,10))
                self.CFont_3.render(self.Sections['Property_Edit'].surf, f'- {self.current_text}', (10,30))

            # Display the warnings
            if self.warning_timer.active:
                for index, warning in enumerate(self.warnings):
                    self.CFont_4.render(self.Sections['Render'].surf, warning, (300, 10 + index * 16))

            # Help Section
            if self.Sections['Help'].visible:
                for line, text in enumerate(helping_text):
                    self.CFont_3.render(self.Sections['Help'].surf, text, (10, 10 + (16 * line)))

                self.Sections['Help'].surf.blit(self.mouse_imgs['mouse_left'], (20, 60))
                self.Sections['Help'].surf.blit(self.mouse_imgs['mouse_right'], (20, 100))
                self.Sections['Help'].surf.blit(self.mouse_imgs['mouse_mid'], (20, 140))

            # Info Section
            if self.Sections['Info'].visible:
                for line, text in enumerate(Info_text):
                    self.CFont_3.render(self.Sections['Info'].surf, text, (10, 10 + (16 * line)))

                self.Sections['Info'].surf.blit(self.YT_icon, (1000 - 108, 700 - 108))

        def Other_updates():

            """
                Update some other useful things.
            """

            # Update all the mouse positions
            self.r_mpos = vec2(pygame.mouse.get_pos()) - self.r_offset
            self.diff = self.r_mpos - self.or_mpos
            self.or_mpos = self.r_mpos

            if self.moving_origion:
                self.origion += (self.diff // 1)

            self.mpos = self.r_mpos - self.origion
            self.grid_pos = self.mpos // self.TILESIZE
            self.r_grid_pos = self.r_mpos // self.TILESIZE

            # Update all the tiles
            if self.adding_tile:
                Add_tile()
            if self.removing_tile:
                Remove_tile()

        def Add_tile():
            # Check if the mouse is in the Rendering area first
            if max(0, min(self.r_mpos.x, self.Sections['Render'].surf.get_width())) == self.r_mpos.x and max(0, min(self.r_mpos.y, self.Sections['Render'].surf.get_height())) == self.r_mpos.y:
                if self.current_layer not in self.tile_data:
                    self.tile_data[self.current_layer] = {}

                self.tile_data[self.current_layer][str(self.grid_pos)] = {
                    'Layer': self.current_layer,
                    'Image': list(self.tilesets[self.current_tileset].keys())[self.tile_index],
                    'Pos': [self.grid_pos.x, self.grid_pos.y],
                    'Set': self.current_tileset,
                    'Properties': {}
                    }
                    
        def Remove_tile():
            # Check if the mouse is in the Rendering area first
            if max(0, min(self.r_mpos.x, self.Sections['Render'].surf.get_width())) == self.r_mpos.x and max(0, min(self.r_mpos.y, self.Sections['Render'].surf.get_height())) == self.r_mpos.y:
                if self.current_layer in self.tile_data and str(self.grid_pos) in self.tile_data[self.current_layer]:
                    del self.tile_data[self.current_layer][str(self.grid_pos)]

        def Save(path: str, data: Any):
            write_f(path, str(data))
            self.warning_timer.activate()
            self.warnings.append(f'Saved map in {path}')

        def Load(path: str) -> int:
            try:
                try:
                    self.tile_data = eval(read_f(path))
                except SyntaxError as e:
                    self.tile_data = {}
                self.filepath = path
                return 1
            except FileNotFoundError:
                self.warning_timer.activate()
                self.warnings.append(f'Warning [!] {path} doesn\'t exist')
                return -1

        def Render_Section():
            surf: pygame.Surface = self.Sections['Render'].surf
            surf_size: vec2 = vec2(surf.get_size())

            # Draw all the tiles in tile data
            tile_surf_size = surf_size / self.RENDER_SCALE
            tile_surf: pygame.Surface = pygame.Surface(tile_surf_size)
            tile_surf.fill((25,25,25))

            # Gather tile data and blit onto the tile_surface
            for tile in self.tile_data.keys():
                layers = sorted(self.tile_data[tile].keys(), reverse=True)
                for layer in layers:
                    lookup = self.tile_data[tile][layer]

                    # get the image and the position
                    img: pygame.Surface = self.tilesets[lookup['Set']][lookup['Image']].copy()
                    if lookup['Layer'] != self.current_layer:
                        img.set_alpha(128)
                    pos: vec2 = vec2(lookup['Pos'])*(self.TILESIZE/self.RENDER_SCALE) + (self.origion/self.RENDER_SCALE)
                    pos.y -= (img.get_height() - (self.TILESIZE/2))

                    if max(-self.TILESIZE/self.RENDER_SCALE, min(pos.x, self.Sections['Render'].surf.get_width()/self.RENDER_SCALE)) == pos.x and max(-self.TILESIZE/self.RENDER_SCALE, min(pos.y, self.Sections['Render'].surf.get_height()/self.RENDER_SCALE)) == pos.y:
                        tile_surf.blit(img, pos)
                        if self.selected_tile == lookup:
                            pygame.draw.rect(tile_surf, (200,200,0), (pos.x, pos.y, img.get_width(), img.get_height()), 1)

            # Draw all the lines
            line_surf: pygame.Surface = pygame.Surface(surf_size)

            cols: int = int(surf_size.x // self.TILESIZE)
            rows: int = int(surf_size.y // self.TILESIZE)

            # Draw vertical lines
            for col in range(cols):
                x = (self.origion.x%self.TILESIZE/self.RENDER_SCALE) + (col * self.TILESIZE/self.RENDER_SCALE)
                pygame.draw.line(line_surf, (50,50,50), (x,0), (x, surf_size.y), 1)

            # Draw horizontal lines
            for row in range(rows + 1):
                y = (self.origion.y%self.TILESIZE/self.RENDER_SCALE) + (row * self.TILESIZE/self.RENDER_SCALE)
                pygame.draw.line(line_surf, (50,50,50), (0,y), (surf_size.x, y), 1)

            line_surf.set_colorkey((0,0,0))
            line_surf.set_alpha(60)
            tile_surf.blit(line_surf)

            surf.blit(pygame.transform.scale(tile_surf, tile_surf_size*self.RENDER_SCALE))
            pygame.draw.circle(surf, (255,0,0), self.origion, 3)

        def Tile_Section():
            surf = self.Sections['Tiles'].surf
            self.CFont_3.render(surf, 'Tile Section', (32,10))

            tile = self.current_tile
            scale_factor: float = 0.0

            # Scaling
            if tile.get_width() > tile.get_height():
                scale_factor = 96 / tile.get_width()
            else:
                scale_factor = 96 / tile.get_height()
            tile = pygame.transform.scale(tile, (int(tile.get_width() * scale_factor), int(tile.get_height() * scale_factor)))

            # Blitting
            pygame.draw.rect(surf, (200,175,150), (20,40,120,120), border_radius=6)
            pygame.draw.rect(surf, (10,10,10), (24,44,112,112), border_radius=4)
            surf.blit(pygame.transform.scale(tile, (96,96)), (32, 52))

        def Property_Section():
            surf = self.Sections['Properties'].surf
            self.CFont_3.render(surf, 'Tile Section', (32,10))

            tile =  self.tilesets[self.selected_tile['Set']][self.selected_tile['Image']].copy() if self.selected_tile != None else pygame.Surface((96,96))
            scale_factor: float = 0.0

            # Scaling
            if tile.get_width() > tile.get_height():
                scale_factor = 96 / tile.get_width()
            else:
                scale_factor = 96 / tile.get_height()
            tile = pygame.transform.scale(tile, (int(tile.get_width() * scale_factor), int(tile.get_height() * scale_factor)))

            # Blitting
            pygame.draw.rect(surf, (200,175,150), (20,40,120,120), border_radius=6)
            pygame.draw.rect(surf, (10,10,10), (24,44,112,112), border_radius=4)
            if self.selected_tile != None:
                surf.blit(pygame.transform.scale(tile, (96,96)), (32, 52))

        running: bool = True
        while running:
            for event in pygame.event.get():
                if event.type == pygame.QUIT:
                    running = False
                    pygame.quit()
                    sys.exit()

                if event.type == pygame.KEYDOWN:
                    if self.accepting_text:
                        if event.key != pygame.K_BACKSPACE:
                            self.current_text = self.current_text + event.unicode if event.unicode in self.CFont_1.char_order else self.current_text
                        else:
                            self.current_text = self.current_text[:-1]

                    if event.key == pygame.K_r and not self.prompting:
                        self.origion = vec2()

                    # Layer change shortcuts
                    if event.key == pygame.K_0:
                        self.current_layer = 0
                    if event.key == pygame.K_1:
                        self.current_layer = 1
                    if event.key == pygame.K_2:
                        self.current_layer = 2
                    if event.key == pygame.K_3:
                        self.current_layer = 3
                    if event.key == pygame.K_4:
                        self.current_layer = 4

                    if event.key == pygame.K_s and self.current_layer in self.tile_data and not self.prompting:
                        self.selected_tile = self.tile_data[self.current_layer][str(self.grid_pos)] if str(self.grid_pos) in self.tile_data[self.current_layer] else None

                    if event.key == pygame.K_LCTRL or event.key == pygame.K_RCTRL:
                        self.func2 = True

                    if event.key == pygame.K_s and self.func2:
                        Save(self.filepath, self.tile_data)

                    if event.key == pygame.K_LALT or event.key == pygame.K_RALT:
                        self.moving_origion = True

                    # Update current tile and all that
                    if self.prompting == False:
                        if event.key == pygame.K_UP:
                            self.tileset_index += 1
                            self.tileset_index %= len(self.tileset_list)
                            self.tile_index = 0

                            self.current_tileset: str = self.tileset_list[self.tileset_index]
                            self.tile_list: list = list(self.tilesets[self.current_tileset].values())
                            self.current_tile: pygame.Surface = self.tile_list[self.tile_index]

                        if event.key == pygame.K_DOWN:
                            self.tileset_index -= 1
                            self.tileset_index %= len(self.tileset_list)
                            self.tile_index = 0

                            self.current_tileset: str = self.tileset_list[self.tileset_index]
                            self.tile_list: list = list(self.tilesets[self.current_tileset].values())
                            self.current_tile: pygame.Surface = self.tile_list[self.tile_index]

                        if event.key == pygame.K_LEFT:
                            self.tile_index -= 1
                            self.tile_index %= len(self.tile_list)
                        
                            self.current_tile: pygame.Surface = self.tile_list[self.tile_index]

                        if event.key == pygame.K_RIGHT:
                            self.tile_index += 1
                            self.tile_index %= len(self.tile_list)
                        
                            self.current_tile: pygame.Surface = self.tile_list[self.tile_index]

                if event.type == pygame.KEYUP:
                    if event.key == pygame.K_LCTRL or event.key == pygame.K_RCTRL:
                        self.func2 = False

                    if event.key == pygame.K_LALT or event.key == pygame.K_RALT:
                        self.moving_origion = False

                if event.type == pygame.MOUSEBUTTONDOWN:
                    if event.button == 2:
                        self.moving_origion = True

                    if event.button == 1 and self.prompting == False:
                        self.adding_tile = True

                    if event.button == 3 and self.prompting == False:
                        self.removing_tile = True
                
                if event.type == pygame.MOUSEBUTTONUP:
                    if event.button == 2:
                        self.moving_origion = False

                    if event.button == 1:
                        self.adding_tile = False

                    if event.button == 3:
                        self.removing_tile = False

            Clear()
            Other_updates()
            Tile_Section()
            Property_Section()
            Render_Section()
            Draw_text()
            Button_update()
            Draw_Sections()

            self.warning_timer.update()
            if not self.warning_timer.active:
                self.warnings = []

            if self.hovering != None:
                if pygame.mouse.get_pos()[0] < self.SCREEN_SIZE.x//2:
                    debug(self.display, self.hovering.hover_text, pygame.mouse.get_pos())
                else:
                    debug(self.display, self.hovering.hover_text, pygame.mouse.get_pos(), left=True)

            self.update_display()


    def run(self):

        """
            Run the editor's main loop
        """

        self.run_Editor()