"""
    All default data the game might need ...
"""

# Default Fragment and Vertex Shaders
default_vert_shader: str = """
#version 330

in vec2 vert;
in vec2 texcoord;
out vec2 uv;

void main() {
  uv = texcoord;
  gl_Position = vec4(vert, 0.0, 1.0);
}
"""

default_frag_shader: str = """
#version 330

uniform sampler2D surface;

out vec4 f_color;
in vec2 uv;

void main() {
  vec3 col = texture(surface, uv).rgb;
  f_color = vec4(col, 1.0);
}
"""

# Input related stuff
char_order: list[str] = [
    'A', 'B', 'C', 'D', 'E', 'F', 'G', 'H', 'I', 'J', 'K', 'L', 'M', 'N', 'O', 'P', 'Q', 'R', 'S', 'T', 'U', 'V', 'W', 'X', 'Y', 'Z', 'a', 'b', 'c', 'd', 'e', 'f', 'g', 'h',
    'i', 'j', 'k', 'l', 'm', 'n', 'o', 'p', 'q', 'r', 's', 't', 'u', 'v', 'w', 'x', 'y', 'z', '0', '1', '2', '3', '4', '5', '6', '7', '8', '9', '#', '!', '?', '.', ',', '[',
    ']', '(', ')', '/', '\\', '=', '+', '-', '*', '"', "'", '_', '<', '>', '|', '@', '$', '%', ':', ' ', '~'
    ]